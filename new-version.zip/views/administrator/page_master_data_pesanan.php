<?php include "includes/header.php" ?>
<?php error_reporting(E_ALL ^ (E_NOTICE ));?>

        <div id="page-wrapper">



            <div class="container-fluid">



                <!-- Page Heading -->

                <div class="row">

                    <div class="col-lg-12">

                        <h1 class="page-header">

                            Master Search <small> Mencari Informasi pesanan</small>

                        </h1>

                        

                    </div>

                </div>

				

				<!-- Info Client -->
				
				
				<form method="post" action="<?=base_url()?>administrator/main/master_data_pesanan">
					<div class="form-group">
						<label class="col-sm-2">Nama Customer</label>
						<div class="col-sm-10">
							<input name="customer_name" id="customer_name" class="customer_name form-control" type="text" value="<?php if(!empty($arr['customer_name'])){echo $arr['customer_name'];}else{echo '';}?>" placeholder="Nama Customer" >
							<input type="hidden" class="form-control" id="customer_id" name="customer_id" ><br/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2">Tanggal Pesanan</label>
						<div class="col-sm-10">
							<input class="datepicker" name="date_awal" placeholder="Pilih Tanggal" value="<?php if(!empty($arr['date_awal'])){echo $arr['date_awal'];}else{echo '';}?>"> Sampai Dengan <input class="datepicker" name="date_akhir"value="<?php if(!empty($arr['date_akhir'])){echo $arr['date_akhir'];}else{echo '';}?>" placeholder="Pilih Tanggal"><br/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2">Nama Product</label>
						<div class="col-sm-10">
							<input name="product_name" id="product_name" class="product_name form-control" type="text" value="<?php if(!empty($arr['product_name'])){echo $arr['product_name'];}else{echo '';}?>" placeholder="Nama Product" >
							<input type="hidden" class="form-control" id="product_id" name="product_id" ><br/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2">Status Pesanan </label>
						<div class="col-sm-10">
							<select class="form-control" name="status_pesanan">
								<option value="all">All Status</option>
								<option value="keep"<?php if($arr['status_pesanan']=="keep"){ echo "selected"; } ?>>Only Keep</option>
								<option value="dropship"<?php if($arr['status_pesanan']=="dropship"){ echo "selected"; } ?>>Only Dropship</option>
							</select><br/>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2">Status Pembayaran </label>
						<div class="col-sm-10">
							<select class="form-control" name="status_pembayaran">
								<option value="all">All Status</option>
								<option value="paid"<?php if($arr['status_pembayaran']=="paid"){ echo "selected"; } ?>>Lunas</option>
								<option value="unpaid"<?php if($arr['status_pembayaran']=="unpaid"){ echo "selected"; } ?>>Belum Lunas</option>
							</select>
						</div>
					</div>
					<input type="hidden" name="cari" value="<?php echo "cari";?>" >
					<div class="form-group">
						<div class="col-sm-12">
							<input type="submit" value="Filter" class="btn btn-primary">
						</div>
					</div>
					
				</form>
				
				<?php if($output->output != null) { ?>
				<div class="container col-sm-12">
				  <h4 class="page-header">

                            Filter Search <small></small>

                        </h4>
				<?=$this->session->flashdata('message') ?>
				<?= $output->output; ?>
				</div>
				<?php }?>
				<hr/>
				<br/>
				<br/>
				
				

            </div>

            <!-- /.container-fluid -->



        </div>

		
<!--- AUTOCOMPLETE ---->

<script type='text/javascript'>
		var site = "<?php echo site_url();?>";

		$(function(){
			$('#customer_name').autocomplete({
				serviceUrl: site+'administrator/main/search_id_customer',
				onSelect: function (suggestion) {
					$('#customer_id').val(suggestion.data);
				}
			});	
		});
		
		$(function(){
			$('#product_name').autocomplete({
				serviceUrl: site+'administrator/main/search_id_produk_item',
				onSelect: function (suggestion) {
					$('#product_id').val(suggestion.data);
				}
			});	
		});
		
		$(function(){
			$('.datepicker').datepicker({
				format: 'yyyy-mm-dd'
			});
		});
</script>
<?php include "includes/footer.php" ?> 