<?php include "includes/header.php"; ?>

<!-- Content
================================================== -->
<div id="page-wrapper">

    <div class="container-fluid">

	    	<!-- Page Heading -->
	    <div class="row">
	        <div class="col-lg-12">
	            <h1 class="page-header">
	               Kirim Pesan (multiple)
	            </h1>
	            <ol class="breadcrumb">
	                <li class="active">
	                    <i class="fa fa-fw fa-edit"></i>  Kirim Pesan (multiple)
	                </li>
	            </ol>
	        </div>
	    </div>
	    <!-- /.row -->
    
    	<?=$this->session->flashdata('message') ?>
	
		<?=form_open('administrator/main/message_to_multiple_process'); ?>
	
			<div class="row">
			<div class="col-md-6">
			<p><strong>Subject</strong></p>
			<input type="text" name="subject"  class="form-control" placeholder="type here..."/><br/>
			<p><strong>Message</strong></p>
			<textarea name="content" rows="10"  class="form-control" placeholder="type here..."></textarea><br/>
			<button type="submit" name="btn_send" class="btn btn-success">SEND</button>
			</div>
			<div class="col-md-6">
			<p><strong>Recipient</strong></p>
			<select type="select-multiple" multiple="multiple" class="form-control" style="height:200px;" id="customer_id" name="customer_id[]" >
			
			<?php foreach($list_customer->result() as $customers): ?>
				<option value="<?=$customers->id ?>"><?=$customers->id ?> (<?=$customers->name?>) </option>
			<?php endforeach; ?>
			</select>
			<br/>
			<button type="button" id="select_all" class="btn btn-info">Select All</button>
			</div>
		</div>
		
		<?=form_close()?>
		<br/>
    </div>

 </div>

<?php include "includes/footer.php"; ?>
<script type="text/javascript">
$('#select_all').click(function() {
    $('#customer_id option').prop('selected', true);
});
</script>