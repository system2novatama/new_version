<?php include "includes/header.php"; ?>



<!-- Content

================================================== -->

<div id="page-wrapper">



    <div class="container-fluid">



	   	<!-- Page Heading -->

	    <div class="row">

	        <div class="col-lg-12">

				

	            <h1 class="page-header">

	               Edit Pengiriman Pesanan - <small>Dropship Detail</small>

	            </h1>

	        </div>

	    </div>

	    <!-- /.row -->

    

    	<?=$this->session->flashdata('message') ?>

		<?php echo validation_errors(); ?>

		<?=form_open('administrator/main/create_order_dropship_process') ?>

		<table class="table table-bordered">
			<tbody>
				<tr>
					<td><strong>No ID Pesanan</strong></td>
					<td><input type="hidden" name="order_id" id="order_id" value="<?=$orders['id'] ?>"/><?=$orders['id'] ?></td>
				</tr>
				<tr>
					<td><strong>Customer </strong></td>
					<td><?=$customer['name'] ?> (<?=$customer['id'] ?>)</td>
				</tr>
				
				
				<tr>
					<td><strong>Dikirim Dari</strong></td>
					<td>
					<span id="notif_from"><font color="red">Wajib diisi*</font></span><br/>
					<textarea name="shipping_from" class="form-control"><?=set_value('shipping_from') ?><?=$orders['shipping_from'] ?></textarea></td>
				</tr>
				<tr>
					<td><strong>Kepada</strong></td>
					<td>
					<span id="notif_to"><font color="red">Wajib diisi*</font></span><br/>
					<textarea name="shipping_to" class="form-control"><?=set_value('shipping_to') ?><?=$orders['shipping_to'] ?></textarea></td>
				</tr>
				<tr>
					<td><strong>Provinsi</strong></td>
					<td>
					<span id="notif_provinsi"><font color="red">Wajib diisi*</font></span><br/>
					<select name="prov_id" class="form-control" id="prov_id">
						
						<?php if($orders['prov_id'] != 0) { ?>
						<?php $data_provinsi = $this->main_model->get_detail('jne_provinsi',array('provinsi_id' => $orders['prov_id'])) ?>
						<option value="<?=$orders['prov_id']?>" ><?=$data_provinsi['provinsi_nama'] ?></option>
						<?php } ?>
						
						<option value="">- Pilih Provinsi -</option>
						<?php foreach($provinsi->result() as $prov) : ?>

							<option value="<?=$prov->provinsi_id?>"><?=$prov->provinsi_nama ?></option>

						<?php endforeach; ?>
					</select></td>
				</tr>
				<tr>
					<td><strong>Kota</strong></td>
					<td>
					<span id="notif_kota"></span><br/>
					<select name="kota_id" class="form-control" id="kota_id">
					<?php if($orders['kota_id'] != 0) { ?>
					<?php $data_provinsi = $this->main_model->get_detail('jne_kota',array('kota_id' => $orders['kota_id'])) ?>
					<option value="<?=$orders['kota_id']?>" ><?=$data_provinsi['kota_nama'] ?></option>
					<?php } ?>
					
						<option value="">- Pilih Kota -</option>
					</select></td>
				</tr>
				<tr>
					
					<td><strong>Total Belanja</strong><span class="pull-right">Rp. </span></td>
					<td><input type="hidden" name="total_before" id="total_before" value="<?=$total_belanja ?>"/><?=numberformat($total_belanja) ?></td>
				</tr>
				<tr>
					<td><strong>Total Berat</strong></td>
					<td><input type="hidden" name="shipping_weight" id="shipping_weight" value="<?=$orders['shipping_weight'] ?> "/><?=$orders['shipping_weight'] ?> Kg ---> Ongkir <strong><?=ceil($orders['shipping_weight']) ?> Kg</strong></td>
				</tr>
				<tr>
					<td><strong>Total Ongkos Kirim</strong><span class="pull-right">Rp. </span></td>
					<td><label><input  type="checkbox" name="shipping_manual" id="shipping_manual"/> Ongkos kirim manual </label>
					<input type="number" name="shipping_fee" id="shipping_fee" class="form-control" value="<?=$orders['shipping_fee'] ?>" readonly /></td>
				</tr>
				
				<tr>
					<td><strong>Total Pembayaran</strong><span class="pull-right">Rp. </span></td>
					<td><input type="text" name="total_after" id="total_after" class="form-control input-lg" value="<?=$orders['total'] ?>" readonly /></td>
				</tr>	
			</tbody>
		</table>
		
		<button name="submit" type="submit" class="btn btn-success">Simpan Pesanan</button>
		<?=form_close()?>

	
    </div>
 </div>

<?php include "includes/footer.php"; ?>

<script type="text/javascript" src="https://code.jquery.com/jquery-1.8.1.min.js"></script>

<script type="text/javascript">

	var base_url = "<?=base_url()?>";
	
	$("#prov_id").change(function(){

			

			var prov_id = $(this).val();

			$("#kota_id").html("<option>Loading....</option>");

			

			$.post(base_url+"administrator/main/get_kota", { prov_id: prov_id, <?=$this->security->get_csrf_token_name()?>: "<?=$this->security->get_csrf_hash()?>"},

			   function(data){

				

				$("#kota_id").html("");
				
				$("#kota_id").html("<option>- Pilih Kota -</option>");

				for (var i=0;i<data.list.length;i++)

				{

					var x = "<option value='"+data.list[i].kota_id+"'>"+data.list[i].kota_nama+"</option>";

					

					$("#kota_id").append(x);

				}

				 $("#notif_kota").html("<font color='red'>Silahkan Pilih kota</font>");

			}, "json");

		});	

		

		$("#kota_id").change(function(){

			

			var kota_id = $(this).val();

			$("#shipping_fee").val("Loading...");

		

			$.post(base_url+"administrator/main/get_shipping_fee", { kota_id: kota_id, <?=$this->security->get_csrf_token_name()?>: "<?=$this->security->get_csrf_hash()?>"},

			   function(data){

				var total_weight = Math.ceil($('#shipping_weight').val());

				var total_shipping_fee = parseFloat(total_weight) * parseFloat(data.tarif);

				var total_before = $("#total_before").val();

				var total_payment = parseFloat(total_before) + parseFloat(total_shipping_fee);

				$("#shipping_fee").val(total_shipping_fee);

				$("#total_after").val(total_payment);


			}, "json");

		});	
		
		$("#shipping_manual").click(function(){
			
			
			if($(this).attr('checked')) 
			{
				$("#shipping_fee").removeAttr("readonly");
			}
			else
			{
				$("#shipping_fee").attr("readonly","readonly");
			}	
			
		});
		
		$("#shipping_fee").keyup(function(){
		
			if($("#shipping_manual").attr('checked')) 
			{
				var total_before = $("#total_before").val();
				var total_shipping_fee = $(this).val();
				
				if(total_shipping_fee == '')
				{
					var total_payment = total_before;
				}
				else
				{
					var total_payment = parseFloat(total_before) + parseFloat(total_shipping_fee);
				}
				

				$("#total_after").val(total_payment);	
			}
		});

</script>