

jQuery(document).ready(function ($) {

    $(".sroll-bar, .side-nav-wrapper").mCustomScrollbar({
      setHeight:550,
      theme:"minimal-dark"
    });

    $('.datepicker').datepicker();
    
    var url = window.location.pathname, 
    urlRegExp = new RegExp(url.replace(/\/$/,'') + "$"); // create regexp to match current url pathname and remove trailing slash if present as it could collide with the link in navigation in case trailing slash wasn't present there
    // now grab every link from the navigation
    $('.side-nav a').each(function(){
        // and test its normalized href against the url pathname regexp
        if(urlRegExp.test(this.href.replace(/\/$/,''))){
            $(this).addClass('active');
        }
    });

     $('.search-input').multicomplete({
         minimum_length: 1,
         result_template: function(result, group, matched_field) {
              tmpl = '<div>';
              if(!!result.name_product) {
                  tmpl += '<a href="#">' + result.name_product + '</a>';
              }
              if(!!result.name) {
                  tmpl += '<a href="#">' + result.name + '</a>';
              }
              tmpl += '</div>';
              return tmpl;
         },
         source: 'http://127.0.0.1:8080/tokomobile_admin/application/views/administrator/includes/demo-source.json'
     }); 
});



