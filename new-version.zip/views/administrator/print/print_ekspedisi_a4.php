<?php
$data_info_kontak = $this->main_model->get_detail('content',array('id' => 3));
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Struk Belanja</title>

<style>

body {margin:0;padding:0;font-family: Arial;text-transform: uppercase;font-size: 14px;color: #666666;}
p {margin:0;padding:0;}
.clear {clear: both;}
#wrapper {width: 960;margin-left: auto;margin-right:auto;padding: 20px;}
.border {
	padding:20px;
	border:2px solid #333;
}

</style>



</head>

<body>

<div id="wrapper">
	<div class="border">
	<table>
	<tr>
	<td>
		<?=$data_info_kontak['value'] ?>
		</td>
		</tr>
	</table>	
	</div>
	<div class="border">
	<br/>
	
	<table width="100%">
		<tr>
			<td>tanggal: <?=date('D, d-m-Y H:i:s') ?></td>
			<td>no nota: #<?=$data_orders['id'] ?></td>
			<td>customer: <?=$customer['name'] ?> (<?=$customer['id'] ?>)</td>
		</tr>
	</table>
	
	
	</div>
	
	<div class="border">
	<h2>DATA BELANJA</h2>
		<table width="100%">
			<tr>
				<td width="50%"><strong>items</strong></td>
				<td width="15%"><strong>qty</strong></td>
				<td width="35%"><strong>harga</strong></td>
			</tr>
			
			<?php 
			$i = 1;
			$total_qty = 0;
			foreach($orders_item->result() as $orders) : 
			$data_customer = $this->main_model->get_detail('customer',array('id' => $orders->customer_id));
			$data_product = $this->main_model->get_detail('product',array('id' => $orders->prod_id));
			$data_color = $this->main_model->get_detail('product_variant',array('id' => $orders->variant_id));
			$total_qty = $total_qty + $orders->qty;
			?>
				<tr>
					<td><?=$data_product['name_item'] ?><br/><?=$data_color['variant']?></td>
					<td><?=$orders->qty ?></td>
					<td>Rp <?=numberformat($orders->subtotal) ?></td>
				</tr>	
				
			<?php 
			$i++;
			endforeach; ?>	
			
		</table>
		
		<hr/>
		<table width="100%">
			<tr>
				<td><strong>total barang (QTY) :</strong></td>
				<td><strong><?=$total_qty?> Pcs</strong></td>
			</tr>
			<tr>
				<td><strong>total belanja :</strong></td>
				<td><strong>Rp <?=numberformat($total) ?></strong></td>
			</tr>
			<tr>
				<td><strong>total ongkir :</strong></td>
				<td><strong>Rp <?=numberformat($data_orders['shipping_fee']) ?></strong></td>
			</tr>
			
		</table>
		
		<div class="clear"></div>
	</div>
	
	<div class="border">
	<h2>DATA SHIPPING</h2>
	
		<table width="100%">
			<tr>
				<td width="50%"><strong>FROM : </strong></td>
				<td width="50%"><strong>TO : </strong></td>
			</tr>
			<tr>
				<td width="50%"><?=$data_orders['shipping_from'] ?></td>
				<td width="50%"><?=$data_orders['shipping_to'] ?></td>	
			</tr>
		</table>
	</div>
	
	
	<br/><br/>
	
</div>

</body>
</html>

<script type="text/javascript">
window.print();

window.location = "<?=$url_redirect?>";
</script>