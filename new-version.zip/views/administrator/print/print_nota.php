<?php
$data_info_kontak = $this->main_model->get_detail('content',array('id' => 3));
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Struk Belanja</title>

<style>
@font-face {font-family: BPdots;src: url(fonts/BPdots.otf);}
body {margin:0;padding:0;font-family: Arial;text-transform: uppercase;font-size: 10px;color: #666666;}
p {margin:0;padding:0;}
.clear {clear: both;}
#wrapper {width: 220px;margin: 0;padding: 0;margin-bottom:30px;}
.header {border-bottom:1px solid #666666;padding:0 0 10px 0;}
.header p {text-align:center;}
.informasi {border-bottom:1px solid #666666;padding:10px 0;}
.daftar_belanja {border-bottom:1px solid #666666;padding:10px 0;}
.daftar_belanja table {font-size:10px;	}
.total_harga {border-top: 1px solid #666666;margin-top: 20px;padding: 10px 0;}
.total_harga .right {float: right;}
.footer p {text-align:center;padding:20px 0 30px 0; height:80px;}
</style>


</head>

<body>

<div id="wrapper">
	<div class="header">
	<?=$data_info_kontak['value'] ?>
		
	</div>	
	
	<div class="informasi">
		<p>tanggal: <?=date('D, d-m-Y H:i:s') ?></p>
		<p>id pesanan: <?=$orders['id'] ?></p>
		<p>customer: <?=$customer['name'] ?></p>
		<p>customer ID: <?=$customer['id'] ?></p>
	</div>
	
	<div class="daftar_belanja">
		<table>
			<tr>
				<td width="60%">items</td>
				<td width="5%">qty</td>
				<td width="35%" style="text-align: right;">harga</td>
			</tr>
			
			<?php 
			$i = 1;
			$total_qty = 0;
			foreach($orders_item->result() as $orders_item) : 
			$data_product = $this->main_model->get_detail('product',array('id' => $orders_item->prod_id));
			$data_variant = $this->main_model->get_detail('product_variant',array('id' => $orders_item->variant_id));
			$total_qty = $total_qty + $orders_item->qty;
			?>
				<tr>
					<td><?=$data_product['name_item'] ?><br/><?=$data_variant['variant']?></td>
					<td><?=$orders_item->qty ?></td>
					<td>Rp<?=numberformat($orders_item->subtotal) ?></td>
				</tr>	
				
			<?php 
			$i++;
			endforeach; ?>

				<tr>
					<td>Ongkos Pengiriman<br/></td>
					<td><?=$orders['shipping_weight'] ?> Kgs</td>
					<td>Rp<?=numberformat($orders['shipping_fee']) ?></td>
				</tr>	
			
		</table>
		
		<div class="total_harga">
			<span class="left">total barang (QTY) :</span> <span class="right"><?=$total_qty?> Pcs</span><br/>
			<span class="left">total harga :</span> <span class="right">Rp<?=numberformat($total) ?></span>
		</div>
		<div class="clear"></div>
	</div>
	
	<div class="footer">
		<p>barang yang sudah anda beli tidak dapat dikembalikan. terima kasih telah belanja.</p>
	</div>
</div>

</body>
</html>

<script type="text/javascript">
window.print();
window.location = "<?=$url_redirect?>";
</script>