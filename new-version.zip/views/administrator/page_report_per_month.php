<?php include "includes/header.php"; ?>

<script type="text/javascript">

var table_name = '<?= $table_name; ?>';

</script>

<!-- Content

================================================== -->

<div id="page-wrapper">



    <div class="container-fluid">



        <!-- Page Heading -->

        <div class="row">

            <div class="col-lg-12">

                <h1 class="page-header">

                    Lihat laporan penjualan (Bulanan) <small> Check laporan per bulan</small>

                </h1>

                <ol class="breadcrumb">

                    <li class="active">

                        <i class="fa fa-list"></i> Laporan Bulanan

                    </li>

                </ol>

            </div>

        </div>

        <!-- /.row -->

        <div class="row">

            <div class="col-lg-12">

            	<?=form_open('administrator/main/report_per_month_process') ?>

	            	Bulan :<input type="text" name="month" class="datepicker" data-date-format="yyyy-mm" data-date-viewmode="years" data-date-minviewmode="months" readonly /> 

					<button type="submit" class="btn btn-success"><i class="fa fa-search"></i> LIHAT LAPORAN</button>

				<?=form_close()?>

            </div>

        </div>

    </div>

</div>



<?php include "includes/footer.php"; ?>

