<?php include "includes/header.php" ?>



        <div id="page-wrapper">



            <div class="container-fluid">



                <!-- Page Heading -->

                <div class="row">

                    <div class="col-lg-12">

                        <h1 class="page-header">

                            Dashboard <small> Statistik Keseluruhan</small>

                        </h1>

                        

                    </div>

                </div>

				

				<!-- Info Client -->
                <?=$this->session->flashdata('message') ?>
				<div id="alret_update" class="alert alert-info" role="alert" hidden>
                <form method="post" action="<?= base_url(); ?>administrator/main/update_vertion">
				<strong>Attantion : </strong>Update version terbaru telah tersedia <button type="submit" class="btn button-update btn-primary offset10">Update</button>
				</form>
                </div>

				<div class="well">

				 <div class="row">

                     <div class="span3 col-md-4">

                       <h4><strong><?=$client_name?>  </strong> </h4>

					    <h5><strong>PACKAGE :</strong> <?=$package?>  </h5>

                    </div>

                  

                    <div class="span3 col-md-4">

                     <h5><strong> MAKSIMAL PRODUK :</strong> <?=$total_max_product?> <br/>

					 <strong>PRODUK TER-PUBLISH : </strong> <?=$total_publish_product?> <br/>

					 <strong>SISA KUOTA PRODUK : </strong> <?=$total_available_space_product?> <br/>

					 </h5>

                    </div>
					
					 <div class="span3 col-md-4">

                     <h5><strong> MAKSIMAL CUSTOMER :</strong> <?=$total_max_customer?> <br/>

					 <strong>JUMLAH CUSTOMER ANDA : </strong> <?=$total_customer?> <br/>

					 <strong>SISA KUOTA CUSTOMER : </strong> <?=$total_available_space_customer?> <br/>

					 </h5>

                    </div>

					 

                </div>
			
				</div>
				
				<div class="well">

                       Anda Dapat meng-upgrade Paket untuk mendapatkan Kuota Produk lebih besar. Hubungi Contact Sales kami. Terima kasih

                    </div>

				<!-- End info client -->

				<hr/>

                <!-- /.row -->
				<!-- Modal Update Version -->
				<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
								<h4 class="modal-title" id="myModalLabel">Pemberitahuan Update Version</h4>
							</div>

							<div class="modal-body">
								<strong>Dear client,</strong>
								<br/>
								<br/>
								Kami sudah mengupload update versi terbaru dari tokomobile
								anda bisa langsung mengklik tombol update untuk melakukan update
								secara otomatis.
								<br/>
								Untuk info lebih lanjut bisa silahkan menghubungi bagian 
								marketing kami
								<br/>
								<br/>
								<p>
								Terima Kasih
								<br/>
								<br/>
								<br/>
								Tokomobile.co.id
								</p>
							</div>

							<div class="modal-footer">
								<label><input id="checkbox" type="checkbox" class="check-popup" name="dismiss">Don't show again!</label><br />
								<form method="post" action="<?= base_url(); ?>administrator/main/update_vertion">
                                <button type="button" class="btn close-button" data-dismiss="modal" aria-hidden="true">Close</button>
                                <button type="submit" class="btn button-update btn-primary offset10">Update</button>
                                </form>
							</div>
						</div>
					</div>
				</div>
				<hr/>

                <!-- END MODAL -->
				

                <div class="row">

                    <div class="span3 col-md-4">

                        <a href="<?= base_url()?>administrator/main/order_all" class="btn btn-warning btn-block btn-lg"><i class="fa fa-shopping-cart"></i> Pesanan </a>    

                    </div>

                    <div class="span3 col-md-4">

                        <a href="<?= base_url()?>administrator/main/customer" class="btn btn-danger btn-block btn-lg"><i class="fa fa-user"></i> Pelanggan </a>  

                    </div>

                   

                    <div class="span3 col-md-4">

                        <a href="<?= base_url()?>administrator/main/report_per_day" class="btn btn-success btn-block btn-lg"><i class="fa fa-search"></i> Laporan</a>    

                    </div>

                </div>

                <!-- /.row -->

				

				<hr/>

                <div class="row">

                    <div class="statistik-wrapper">

                        <div class="col-lg-12">

                            <h4 class="page-header">Statistik Penjualan </h4>

                            <div style="width:100%; margin-bottom: 15px;">

                                <div>

                                    <canvas id="canvas" height="250" width="960"></canvas>

                                </div>

                            </div>

                            <script>

                                var randomScalingFactor = function(){ return Math.round(Math.random()*100)};

                                var lineChartData = {

                                    labels : <?php echo $last_chart_date ?>,

                                    datasets : [

                                        

                                        {

                                            label: "Statistik Pesanan",

                                            fillColor : "rgba(151,187,205,0.2)",

                                            strokeColor : "rgba(151,187,205,1)",

                                            pointColor : "rgba(151,187,205,1)",

                                            pointStrokeColor : "#fff",

                                            pointHighlightFill : "#c00000",

                                            pointHighlightStroke : "rgba(151,187,205,1)",

                                            data : <?php echo $last_chart_order ?>

                                        }

                                    ]



                                }



                                window.onload = function(){

                                    var ctx = document.getElementById("canvas").getContext("2d");

                                    window.myLine = new Chart(ctx).Line(lineChartData, {

                                        responsive: true

                                    });

                                }

                            </script>

                        </div>

                    </div>

                </div>

                <!-- /.row -->



                <div class="row">

                    <div class="col-lg-12">

                        <h4 class="page-header">Informasi Pesanan </h4>

                        <!-- Nav tabs -->

                        <ul id="myTab" class="nav nav-tabs" role="tablist">

                          <li class="active"><a href="#pesanan-trakhir" role="tab" data-toggle="tab">Pesanan Terakhir</a></li>

                          <li><a href="#stock-table" role="tab" data-toggle="tab">Peringatan Stock</a></li>

                        </ul>



                        <!-- Tab panes -->

                        <div class="tab-content">

                          <div class="tab-pane active" id="pesanan-trakhir">

                            <div class="col-lg-12 table-wrapper">

                                <table class="table table-bordered table-hover table-striped">

                                    <thead>

                                        <tr>

                                            <th>#</th>

                                            <th>Customer ID</th>

                                            <th>Nama Customer</th>

                                            <th>Item</th>

                                            <th>QTY</th>

                                            <th>Subtotal</th>

                                        </tr>

                                    </thead>

                                    <tbody>

                                        <?php 

                                            $i = 1;

                                            foreach($last_order->result() as $orders): 

                                            $data_product = $this->main_model->get_detail('product',array('id' => $orders->prod_id));

                                            $data_color = $this->main_model->get_detail('product_variant',array('id' => $orders->variant_id));

                                            $data_customer = $this->main_model->get_detail('customer',array('id' => $orders->customer_id));

                                        ?>

                                        <tr>

                                            <td><?=$i?></td>

                                            <td><?=$orders->customer_id ?></td>

                                            <td><?=$data_customer['name'] ?></td>

                                            <td><?=$data_product['name_item'] ?></td>

                                            <td><?=$orders->qty?></td>

                                            <td><?=$orders->subtotal?></td>

                                            <?php $i++; endforeach; ?>

                                        </tr>

                                    </tbody>

                                </table>

                            </div>

                          </div>

                          <div class="tab-pane" id="stock-table">

                            <div class="col-lg-12 table-wrapper">

                                <table class="table table-bordered table-hover table-striped">

                                    <thead>

                                        <tr>

                                            <th>Item</th>

                                            <th>Color</th>

                                            <th>Sisa Stock</th> 

                                        </tr>

                                    </thead>

                                    <tbody>

                                        <?php 
                                        
                                        	$total_loop = 0;
                                        	foreach($min_stock_product->result() as $products):

                                            $data_product = $this->main_model->get_detail('product',array('id' => $products->prod_id));
                                            
                                            if($data_product['status'] == 'Publish') {
                                            $total_loop++;

                                        ?>

                                        <tr>

                                            <td><?=$data_product['name_item'] ?></td>

                                            <td><?=$products->variant?></td>

                                            <td><?=$products->stock?> Pcs</td>

                                        </tr>   

                                        <?php 
                                        }
                                        
                                        if($total_loop == 10)
                                        {
											break;
										}
                                        endforeach; ?>

                                    </tbody>

                                </table>

                            </div>

                          </div>

                        </div>

                    </div>

                </div>

                <!-- /.row -->



            </div>

            <!-- /.container-fluid -->



        </div>

        <!-- /#page-wrapper -->
		<?php 
		$data_version_update = $this->main_model->get_list('data_version_update',array('perpage' => 1,'offset' => 0),array('by' => 'id','sorting' => 'DESC'));
		$data_version = $data_version_update->row_array();
		$version = $data_version['number_version'];
		?>	
		<script>
		$.post( "http://localhost/_tokomobile_update/development_source/administrator/main/get_data_version", { func: "get_data_version" },
		function( data ) {
	
		var current_version = "<?=$version ?>";
		var current_version = parseFloat(current_version);
		$('#versi').val( data.number_version );
		
		if(current_version < data.number_version)
		{
			
			var remember = document.getElementById('checkbox');
            if (remember.checked){
                $('#myModal').modal('hide')
            }else{
                $('#myModal').modal('show')
            }

			$('#alret_update').show()
			
		}
	
		
		}, "json");



		</script>


 

<?php include "includes/footer.php" ?> 

