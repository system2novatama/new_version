<?php 
include "includes/header.php"; 
$data_info_kontak = $this->main_model->get_detail('content',array('id' => 2));
$data_info_rekening = $this->main_model->get_detail('content',array('id' => 1));
$data_info_nota = $this->main_model->get_detail('content',array('id' => 3));$data_link_android = $this->main_model->get_detail('content',array('name' => 'link_android'));$data_link_blackberry = $this->main_model->get_detail('content',array('name' => 'link_blackberry'));$data_link_windows_phone = $this->main_model->get_detail('content',array('name' => 'link_windows_phone'));
?>
<!-- Content
================================================== -->
<div id="page-wrapper">

			<?=form_open('administrator/main/edit_info_process');?>
            <div class="container-fluid">
							
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Settings Informasi<small> Untuk merubah informasi toko online</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-list"></i> Settings Informasi
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-12">
                        <?= $this->session->flashdata('message'); ?>
                        <?php echo validation_errors(); ?>
                        <ul id="myTab" class="nav nav-tabs">
                                <li class="active"><a href="#general_settings" data-toggle="tab"><b>Update info</b></a></li> 
                        </ul>
                        <div id="myTabContent" class="tab-content" >
                            
                            <!-- General Settings -->
                            <div class="tab-pane fade active in" id="general_settings">
                                <div class="form-horizontal">
                                    <div class="control-group">
                                        <label class="control-label" for="user_name">Info Kontak</label>
                                        <div class="controls">
                                        <textarea name="info_kontak" rows="5" class="col-lg-8"><?=$data_info_kontak['value'] ?></textarea>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="control-group">
                                        <label class="control-label" for="user_email">Info Rekening</label>
                                        <div class="controls">
                                        <textarea name="info_rekening" rows="5" class="col-lg-8"><?=$data_info_rekening['value'] ?></textarea>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="control-group">
                                        <label class="control-label" for="user_email">Header Struk/Nota</label>
                                        <div class="controls">
                                        <textarea name="info_nota" rows="5" class="col-lg-8"><?=$data_info_nota['value'] ?></textarea>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>																		<div class="control-group">                                        <label class="control-label" for="link_android">Link Android</label>                                        <div class="controls">                                        <input type="text" name="link_android" class="col-lg-8" value="<?=$data_link_android['value'] ?>">                                        </div>                                        <div class="clearfix"></div>                                    </div>																		<div class="control-group">                                        <label class="control-label" for="link_blackberry">Link Blackberry</label>                                        <div class="controls">                                        <input type="text"  name="link_blackberry"  class="col-lg-8" value="<?=$data_link_blackberry['value'] ?>" />                                        </div>                                        <div class="clearfix"></div>                                    </div>																											
                                </div>
                            </div>
                        </div>
                        
                        <button type="submit" name="update_settings" class="btn btn-success">Update Settings</button>
                    </div>
                </div>
                <!-- /.row -->
            </div>
			
			<?=form_close()?>
</div>
<script src="<?= base_url() ?>application/views/backend/assets/js/nicedit/nicEdit.js" type="text/javascript"></script>
<script type="text/javascript">
bkLib.onDomLoaded(function() { 
	new nicEditor().panelInstance('signature');
	new nicEditor().panelInstance('new_member_registration');
	new nicEditor().panelInstance('new_order_invoice');
	new nicEditor().panelInstance('order_invoice_paid');
	new nicEditor().panelInstance('order_invoice_cancel');
	new nicEditor().panelInstance('forgot_password');
	new nicEditor().panelInstance('newsletter_registration');
	new nicEditor().panelInstance('admin_new_order');
	new nicEditor().panelInstance('admin_new_payment_confirmation');	
});
</script>
<?php include "includes/footer.php"; ?>