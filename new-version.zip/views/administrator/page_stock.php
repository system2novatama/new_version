<?php include "includes/header.php"; ?>

<!-- Content
================================================== -->
<section id="content" >

	<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Stock <small> Untuk mengetahui stock produk</small>
                        </h1>
                        <h4><a href="<?=base_url()?>administrator/main/order" />Kontrol Stock </a> </h4>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-dashboard"></i> Stock
                            </li>
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <div class="row">
                	<div class="col-lg-12">
					
						<div class="row search-stock-wrapper">
							<div class="search-name-wrapper col-sm-4">
								<form name="form1" id="form1" method="post" action="search_product_stock" >
									<input type='text' id='name_product' class="autocomplete_pro input-text col-sm-10" placeholder="Nama Produk" />
									<input id="id" name='prod_id' class="form-control" type="hidden" readonly>
									<button  type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
								</form>
							</div>
							<div class="search-category-wrapper col-sm-4">
								<form name="form2" id="form2" method="post" action="search_category_stock" >
									<input type='text' id='name_category_prod' class="autocomplete_cat input-text col-sm-10" placeholder="Nama Category Produk" />
									<input id="cat" name='cat_id' class="form-control" type="hidden" readonly>
									<button  type="submit" class="btn btn-info"><i class="fa fa-search"></i></button>
								</form>
							</div>
						</div>

						<?=form_open('administrator/main/stock_update') ?>
                		
						<?=$this->session->flashdata('message') ?>						
						<table class="table table-bordered table-striped">
							<thead>
								<tr>
									<th width="5%">No</th>
									<th>Product</th>
									<th width="15%">Category Product</th>
									<th width="15%">Color / Variant</th>
									<th width="10%">Terjual</th>
									<th width="10%">Sisa Stock</th>
									<th width="15%">Tambah Stock</th>
								</tr>
							</thead>
							<tbody>
							<?php 
							$i = 1 * ($offset + 1);
							
							$total_stock = 0;
							
							$total_terjual = 0;
							
							foreach($list_item->result() as $items) : 
							
							$data_product = $this->main_model->get_detail('product',array('id' => $items->prod_id));

							$category_id = $data_product ['category_id'];

							$data_category = $this->main_model->get_detail('product_category',array('id' => $category_id));
							
							// SUM
							
							$this->db->select_sum('qty');
							
							$this->db->where('variant_id',$items->id);
							
							$orders_items = $this->db->get('orders_item')->row_array();
							
							$total_terjual = $total_terjual + $orders_items['qty'];												
							if($data_product['status'] == 'Publish') {
							
							$total_stock = $total_stock + $items->stock;
							?>
								<tr>
									<td><?=$i ?></td>
									<td><?=$data_product['name_item'] ?></td>
									<td><?=$data_category['name'] ?></td>
									<td><?=$items->variant ?></td>
									<td><?=$orders_items['qty'] ?></td>
									<td><?=$items->stock ?></td>
									<td><input type="hidden" name="item_id[]"  value="<?=$items->id ?>"/>
									<input type="number" name="stock[]" class="form-control input-small" placeholder="0" value="" min="0" />
									</td>
								</tr>
							<?php }
							$i++;
							endforeach; ?>	
							<tr>
								<th colspan="4">TOTAL</th>
								<th><?=$total_terjual; ?></th>
								<th><?=$total_stock?></th>
								<th></th>
							</tr>
							</tbody>
						</table>

						<?=$this->pagination->create_links(); ?>
						<p><button type="submit" name="go" class="btn btn-success" >UPDATE STOCK</button></p>
						<?=form_close()?>
                	</div>
                </div>
                <!-- /.row -->
            </div>
    </div>
<?php include "includes/footer.php"; ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.8.1.min.js"></script>
<script type='text/javascript' src='<?php echo base_url();?>assets/js/jquery.autocomplete.js'></script>
 <script type='text/javascript'>
	var site = "<?php echo site_url();?>";
	
	$(function(){
		$('.autocomplete_pro').autocomplete({
			serviceUrl: site+'administrator/main/search_product_id',
			onSelect: function (suggestion) {
				document.form1.id.value = suggestion.data;
			}
		});

		$('.autocomplete_cat').autocomplete({
			serviceUrl: site+'administrator/main/search_category_id',
			onSelect: function (suggestion) {
				document.form2.cat.value = suggestion.data;
			}
		});	
	});

</script>