<?php include "includes/header.php"; ?>



<!-- Content

================================================== -->

<div id="page-wrapper">



    <div class="container-fluid">



	    	<!-- Page Heading -->

	    <div class="row">

	        <div class="col-lg-12">

	            <h1 class="page-header">

	                Konfirmasi Pembayaran

	            </h1>

	            <ol class="breadcrumb">

	                <li class="active">

	                    <i class="fa fa-fw fa-edit"></i> Konfirmasi Pembayaran

	                </li>

	            </ol>

	        </div>

	    </div>

	    <!-- /.row -->

    

    	<?=$this->session->flashdata('message') ?>

	

		<table class="table table-bordered">

			<tbody>

				<tr>

					<td width="30%"><strong>Nomor Konfirmasi</strong></td>

					<td><?=$confirmation['id']?> </td>

				</tr>	

				<tr>

					<td><strong>ID Pesanan</strong></td>

					<td><?php if($confirmation['order_id'] != 0) { ?><a href="<?=base_url()?>administrator/main/order_detail/<?=$confirmation['order_id'] ?>" target="_blank"> #<?=$confirmation['order_id'] ?></a> <? } else { ?> Tidak ada referensi pesanan<?php } ?></td>
				</tr>
				<tr>

					<td><strong>Tanggal</strong></td>

					<td><?=$confirmation['date'] ?></td>

				</tr>

				<tr>

					<td><strong>Nama</strong></td>

					<td><?=$confirmation['name'] ?></td>

				</tr>

				<tr>

					<td><strong>Jumlah</strong></td>

					<td><?=$confirmation['amount'] ?></td>

				</tr>

				<tr>

					<td><strong>Bank</strong></td>

					<td><?=$confirmation['bank'] ?></td>

				</tr>	

				<tr>

					<td><strong>Rekening</strong></td>

					<td><?=$confirmation['bank_account_number'] ?></td>

				</tr>	

				<tr>

					<td><strong>Status</strong></td>

					<td><?=$confirmation['status'] ?></td>

				</tr>	

			</tbody>

		</table>

		

	

			<a href="<?=base_url()?>administrator/main/confirm_payment_change_status/<?=$confirmation['id']?>/Approve" class="btn btn-success" <?php if($confirmation['order_id']== 0){echo 'readonly';}?> >Approve</a> 

		
		
			<a href="<?=base_url()?>administrator/main/confirm_payment_change_status/<?=$confirmation['id']?>/Approve/Paid" class="btn btn-success" <?php if($confirmation['order_id']== 0){echo 'disabled';}?> >Approve & Lunas</a>

			<a href="<?=base_url()?>administrator/main/confirm_payment_change_status/<?=$confirmation['id']?>/Reject" class="btn btn-danger">Reject</a> 
			
			<a href="<?=base_url()?>administrator/main/confirm_payment" class="btn btn-default pull-right">Back to list</a> 

		

    </div>



 </div>



<?php include "includes/footer.php"; ?>

