<?php include "includes/header.php"; ?>

<script type="text/javascript">

var table_name = '<?= $table_name; ?>';

</script>

<!-- Content

================================================== -->

<div id="page-wrapper">



    <div id="report" class="container-fluid">

    	<!-- Page Heading -->

        <div class="row">

            <div class="col-lg-12">

            	<div class="search_report">

            		<div class="heading-report">

            			<h1 class="page-header">

		                    Lihat laporan penjualan (Harian) <small> Check laporan per hari</small>

		                </h1>

		                <ol class="breadcrumb">

		                    <li class="active">

		                        <i class="fa fa-list"></i> Laporan harian

		                    </li>

		                </ol>

            		</div>

            		<div class="body-report">

            			<?=form_open('administrator/main/report_per_day_process') ?>

			            	Tanggal : <input type="text" name="date" class="datepicker" data-date-format="yyyy-mm-dd"/>  

							<button type="submit" class="btn btn-success"><i class="fa fa-search"></i> LIHAT LAPORAN</button>

						<?=form_close() ?>

            		</div>

            	</div>

            </div>

        </div>

        <!-- /.row -->

    	<div class="row">

    		<div class="col-lg-12">

    			<form action="<?=base_url()?>administrator/main/report_per_day_print" method="post" target="_new">

					<input type="hidden" name="date" value="<?=$this_date ?>"/>

					<button type="submit" class="btn btn-info buton-print"><i class="fa fa-print"></i> PRINT</button>

				</form>

				<table class="table table-bordered table-striped">

					<thead>

					<tr>

						<th>No</th>

						<th>No Nota</th>

						<th>Customer</th>

						<th>Date</th>

						<th>Total Pembelian</th>

						<th>Total Penjualan</th>

						

					</tr>	

						

					</thead>

					

					<tbody>

					<?php 

					$i = 1;

					

					$report_total = 0;

					$total_purchase = 0;	

					foreach($transaksi->result() as $trans): 

					

					// Total Pembelian

					$data_items_trans = $this->main_model->get_list_where('orders_item',array('order_id' => $trans->id));

					

					$this_purchase = 0;

					

					foreach($data_items_trans->result() as $items_trans):

						$data_this_product = $this->main_model->get_detail('product',array('id' => $items_trans->prod_id));

						$this_purchase = $this_purchase + ($data_this_product['price_production'] * $items_trans->qty);

					endforeach;

					$this_total = $trans->total - $trans->shipping_fee;

					

					$report_total = $report_total +$this_total ;

					$data_this_customer = $this->main_model->get_detail('customer',array('id' => $trans->customer_id));

					

					?>

						<tr>

							<td><?=$i ?></td>

							<td>#<?=$trans->id?></td>

							<td><?=$data_this_customer['id'] ?> - <?=$data_this_customer['name'] ?></td>

							<td><?=date("D, d-M-Y",strtotime($trans->order_datetime))?></td>

							<td>Rp. <?=numberformat($this_purchase)?></td>

							<td>Rp. <?=numberformat($this_total)?></td>

						</tr>	

					<?php 

					$i++;

					$total_purchase = $total_purchase + $this_purchase;

					endforeach; ?>	

					

					<tr>

						<th colspan="4">TOTAL</th>

						<th>Rp. <?=numberformat($total_purchase) ?></th>

						<th>Rp. <?=numberformat($report_total) ?></th>

					</tr>

					</tbody>

					

				</table>

    		</div>

    	</div>

    </div>

</div>



<?php include "includes/footer.php"; ?>

