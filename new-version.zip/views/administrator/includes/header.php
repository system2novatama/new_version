<?php

$data_user = $this->main_model->get_detail('users',array('id' => $this->session->userdata('webadmin_user_id')));

//data header

$data_header_order_unpaid = $this->main_model->get_list_where('orders',array('order_payment' => 'Unpaid'),null,array('by' => 'id','sorting' => 'DESC'));

$data_header_order_process = $this->main_model->get_list_where('orders_item',array('order_status' => 'Keep', 'order_payment' => 'Unpaid'),null,array('by' => 'id','sorting' => 'DESC'));

$data_header_confirmation =  $this->main_model->get_list_where('confirmation',array('status' => 'Pending'),null,array('by' => 'id','sorting' => 'DESC'));

$data_header_status =  $this->main_model->get_list_where('customer',array('status' => 'Moderate'),null,array('by' => 'id','sorting' => 'DESC'));

?>



<!DOCTYPE html>

<html lang="en">



<head>



    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">

    <meta name="author" content="">



    <title>Tokomobile - Administrator</title>



    <script src="<?= base_url() ?>application/views/administrator/assets/js/jquery.js"></script>

    

    <script type="text/javascript">

    var base_url = '<?= base_url() ?>';

    </script>

    

    <?php if($output != null) { ?>

    <?php foreach($output->css_files as $file): ?>

    <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />

 

    <?php endforeach; ?>

    

    <?php } ?> 



    <!-- Bootstrap Core CSS -->

    <link href="<?=base_url()?>application/views/administrator/assets/css/bootstrap.css" rel="stylesheet">



    <!-- Custom CSS -->

    <link href="<?=base_url()?>application/views/administrator/assets/css/sb-admin.css" rel="stylesheet">

	<link href='<?php echo base_url();?>assets/css/jquery.autocomplete.css' rel='stylesheet' />

    <link href="<?= base_url() ?>application/views/administrator/assets/css/site.css" rel="stylesheet">

    <link href="<?= base_url() ?>application/views/administrator/assets/js/datepicker/css/datepicker.css" rel="stylesheet">



    <link href="<?= base_url() ?>application/views/administrator/assets/css/jquery-multicomplete.css" rel="stylesheet" media="all" />



    <!-- Scrollbar -->

    <link rel="stylesheet" href="<?= base_url() ?>application/views/administrator/assets/css/jquery.mCustomScrollbar.css">



    <!-- Custom Fonts -->

    <link href="<?=base_url()?>application/views/administrator/assets/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->

    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

    <!--[if lt IE 9]>

        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>

        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->

    <script type="text/javascript" src="<?=base_url()?>application/views/administrator/assets/js/Chart.min.js"></script>

</head>



<body>



    <div class="slide-menu  slide-menu-left">

        <div class="sroll-bar">

            <ul class="nav navbar-nav side-nav">

            

                <li>

                    <a href="<?=base_url()?>administrator/main"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>

                </li>

                 <li>

                    <a href="<?=base_url()?>administrator/main/last_order_process"><i class="fa fa-fw fa-shopping-cart"></i> Pesanan Dalam Proses</a>

                </li>

                 <li>

                    <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-shopping-cart"></i> Data Pesanan <i class="fa fa-fw fa-caret-down"></i></a>

                    <ul id="demo" class="collapse">

                        <li>

                            <a href="<?=base_url()?>administrator/main/order_all">Pesanan (All)</a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/order_unpaid">Pesanan <span class="label label-primary">Belum lunas</span></a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/order_paid">Pesanan <span class="label label-success">Lunas</span></a>

                        </li>

                        

                        <li>

                            <a href="<?=base_url()?>administrator/main/create_order">Buat Pesanan Baru <i class="fa fa-fw fa-plus"></i></a>

                        </li>

                    </ul>

                </li>

                

                <li>

                    <a href="<?=base_url()?>administrator/main/customer"><i class="fa fa-fw fa-list"></i> Data Pelanggan
						<?php if($data_header_status->num_rows() > 0) { ?>

						<span class="label label-danger"><?=$data_header_status->num_rows()?></span> <b class="caret"></b> 

						<?php } ?>

					</a>
					
                </li>

                

                <li>

                    <a href="javascript:;" data-toggle="collapse" data-target="#katalog_ready"><i class="fa fa-fw fa-list"></i> Katalog Ready Stock <i class="fa fa-fw fa-caret-down"></i></a>

                    <ul id="katalog_ready" class="collapse">

                        <li>

                              <a href="<?=base_url()?>administrator/main/product/Ready_Stock/Publish/add">Tambahkan Produk <i class="fa fa-fw fa-plus"></i> </a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/product/Ready_Stock/Publish/">Data Produk <span class="label label-success">Publish</span></a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/product/Ready_Stock/Unpublish/">Data Produk <span class="label label-danger">Unpublish</span></a>

                        </li>

                        

                    </ul>

                </li>

                <li>

                    <a href="javascript:;" data-toggle="collapse" data-target="#katalog_po"><i class="fa fa-fw fa-list"></i> Katalog Pre Order <i class="fa fa-fw fa-caret-down"></i></a>

                    <ul id="katalog_po" class="collapse">

                        <li>

                              <a href="<?=base_url()?>administrator/main/product/PO/Publish/add"> Tambahkan Produk <i class="fa fa-fw fa-plus"></i></a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/product/PO/Publish">Data Produk <span class="label label-success">Publish</span></a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/product/PO/Unpublish">Data Produk <span class="label label-danger">Unpublish</span></a>

                        </li>

                        

                    </ul>

                </li>

                <li>

                    <a href="javascript:;" data-toggle="collapse" data-target="#data_kategori"><i class="fa fa-fw fa-list"></i> Kategori<i class="fa fa-fw fa-caret-down"></i></a>

                    <ul id="data_kategori" class="collapse">

                         <li>

                            <a href="<?=base_url()?>administrator/main/product_category/add">Tambah Kategori <i class="fa fa-fw fa-plus"></i></span></a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/product_category">Data Kategori</a>

                        </li>

                  

                    </ul>

                </li>

                <li>

                    <a href="<?=base_url()?>administrator/main/confirm_payment"><i class="fa fa-fw fa-edit"></i> Konfirmasi Pembayaran</a>

                </li>

            

                 <li>

                    <a href="javascript:;" data-toggle="collapse" data-target="#pesan"><i class="fa fa-fw fa-edit"></i> Kirim Pesan<i class="fa fa-fw fa-caret-down"></i></a>

                    <ul id="pesan" class="collapse">

                        <li>

                            <a href="<?=base_url()?>administrator/main/message/add">Kirim Pesan</a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/message_to_multiple">Kirim Pesan (Multiple)</span></a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/message">History Pesan</span></a>

                        </li>       

                    </ul>

                </li>

                <li>

                    <a href="<?=base_url()?>administrator/main/stock"><i class="fa fa-fw fa-list"></i> Stock</a>

                </li>
				
				<li>

                    <a href="<?=base_url()?>administrator/main/master_data_pesanan"><i class="fa fa-fw fa-search"></i> Master Data Pesanan</a>

                </li>

                <li>

                    <a href="javascript:;" data-toggle="collapse" data-target="#arsip"><i class="fa fa-fw fa-list"></i> Laporan<i class="fa fa-fw fa-caret-down"></i></a>

                    <ul id="arsip" class="collapse">

                        

                        <li>

                            <a href="<?=base_url()?>administrator/main/report_per_day">Laporan Per Hari</span></a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/report_per_month">Laporan Per Bulan</span></a>

                        </li>       

                    </ul>

                </li>

                <li>

                    <a href="javascript:;" data-toggle="collapse" data-target="#pengaturan"><i class="fa fa-fw fa-gear"></i> Pengaturan<i class="fa fa-fw fa-caret-down"></i></a>

                    <ul id="pengaturan" class="collapse">

                        <li>

                            <a href="<?=base_url()?>administrator/main/edit_info">Data Toko Online</a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/ekspedisi_jne_prov">Data JNE</span></a>

                        </li>       

                    </ul>

                </li>    
				
				<li>

                            <a href="<?=base_url()?>administrator/main/logout"><i class="fa fa-fw fa-power-off"></i> Keluar</a>

                        </li>

            </ul>

        </div>

    </div>




    <!-- Site Overlay -->

    <div class="site-overlay"></div>



    <div id="wrapper">



        <!-- Navigation -->

        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">

            <!-- Brand and toggle get grouped for better mobile display -->

            <div class="navbar-header">

                <button type="button" class="navbar-toggle menu-btn">

                    <span class="sr-only">Toggle navigation</span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                </button>

                <a class="navbar-brand" href="index.html"><strong>TOKOMOBILE</strong></a>

            </div>

            <!-- Top Menu Items -->
			<div id="load_content">
            <ul id="load_content" class="nav navbar-right top-nav">

               

				<li class="dropdown">

                    <a href="#" class="dropdown-toggle  top-menu" data-toggle="dropdown"><i class="fa fa-shopping-cart"></i> <span>Pesanan Dalam Proses (Keep)</span> 

						<?php if($data_header_order_process->num_rows() > 0) { ?>

						<span class="label label-danger"><?=$data_header_order_process->num_rows()?></span> <b class="caret"></b> 

						<?php } ?>

					</a>

                    <ul class="dropdown-menu message-dropdown">

					   <li><span>Pesanan Dalam Proses (Keep)</span></li>

					<?php foreach($data_header_order_process->result() as $orders_process): 

					$data_product = $this->main_model->get_detail('product',array('id' => $orders_process->prod_id));

					$data_product_variant = $this->main_model->get_detail('product_variant',array('id' => $orders_process->variant_id));
					
					$data_customer = $this->main_model->get_detail('customer',array('id' => $orders_process->customer_id));

					?>

                         <li class="message-preview">

                            <a href="<?=base_url()?>administrator/main/order_per_customer/<?=$orders_process->customer_id?>"><strong>Customer :  <?=$data_customer['name']?> (<?=$orders_process->customer_id?>)</strong><br/><?=$data_product['name_item'] ?> - <?=$data_product_variant['variant'] ?> <br/> <span class="label label-info"><?=$orders_process->qty?> Pcs</span> <span class="label label-danger">Rp.<?=numberformat($orders_process->subtotal)?></span></a>

                        </li>

					<?php endforeach; ?>	

                    </ul>

                </li>

				 <li class="dropdown">

                    <a href="#" class="dropdown-toggle top-menu" data-toggle="dropdown"><i class="fa fa-exclamation-triangle"></i> <span>Pesanan Belum Lunas (Dropship)</span> 

						<?php if($data_header_order_unpaid->num_rows() > 0) { ?>

						<span class="label label-danger"><?=$data_header_order_unpaid->num_rows()?></span> <b class="caret"></b> 

						<?php } ?>

					</a>

                    <ul class="dropdown-menu message-dropdown">

					   <li><span>Pesanan Belum Lunas (Dropship)</span></li>

					<?php foreach($data_header_order_unpaid->result() as $orders_unpaid): 
					
					$data_customer = $this->main_model->get_detail('customer',array('id' => $orders_unpaid->customer_id));
					?>

                         <li class="message-preview">

                            <a href="<?=base_url()?>administrator/main/order_detail/<?=$orders_unpaid->id?>">ID Pesanan : <strong>#<?=$orders_unpaid->id?> </strong><br/>Customer : <?=$data_customer['name']?> (<?=$orders_unpaid->customer_id?>) <br/><span class="label label-danger">Rp.<?=numberformat($orders_unpaid->total)?></span></a>

                        </li>

					<?php endforeach; ?>	

                    </ul>

                </li>

				<li class="dropdown">

                    <a href="<?=base_url()?>administrator/main/confirm_payment" class="top-menu" ><i class="fa fa-inbox"></i> <span>Konfirmasi</span> 

						<?php if($data_header_confirmation->num_rows() > 0) { ?>

						<span class="label label-danger"><?=$data_header_confirmation->num_rows()?></span> 

						<?php } ?>

					</a>          

                </li>



                <li class="dropdown">

                    <a href="#" class="dropdown-toggle  top-menu" data-toggle="dropdown"><i class="fa fa-user"></i> <span>Akun</span> <b class="caret"></b></a>

                    <ul class="dropdown-menu">

                        <li>

                            <a href="<?=base_url()?>administrator/main/edit_profile"><i class="fa fa-fw fa-user"></i> Profil</a>

                        </li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/message"><i class="fa fa-fw fa-envelope"></i> Pesan</a>

                        </li>

                        

                        <li class="divider"></li>

                        <li>

                            <a href="<?=base_url()?>administrator/main/logout"><i class="fa fa-fw fa-power-off"></i> Keluar</a>

                        </li>

                    </ul>

                </li>

            </ul>
			</div>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->

             <div class="side-nav-wrapper">

                <ul class="nav navbar-nav side-nav">

                   

                    <li>

                        <a href="<?=base_url()?>administrator/main"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>

                    </li>

                     <li>

                        <a href="<?=base_url()?>administrator/main/last_order_process"><i class="fa fa-fw fa-shopping-cart"></i> Pesanan Dalam Proses</a>

                    </li>

                     <li>

                        <a href="javascript:;" data-toggle="collapse" data-target=".demo"><i class="fa fa-fw fa-shopping-cart"></i> Data Pesanan <i class="fa fa-fw fa-caret-down"></i></a>

                        <ul class="collapse demo">

                            <li>

                                <a href="<?=base_url()?>administrator/main/create_order_tamu">Buat Pesanan Tamu <i class="fa fa-fw fa-plus"></i></a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/order_all">Pesanan (All)</a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/order_unpaid">Pesanan <span class="label label-primary">Belum lunas</span></a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/order_paid">Pesanan <span class="label label-success">Lunas</span></a>

                            </li>

                            

                            <li>

                                <a href="<?=base_url()?>administrator/main/create_order">Buat Pesanan Baru <i class="fa fa-fw fa-plus"></i></a>

                            </li>

                        </ul>

                    </li>

                    

                    <li>

                        <a href="<?=base_url()?>administrator/main/customer"><i class="fa fa-fw fa-list"></i> Data Pelanggan 
							<?php if($data_header_status->num_rows() > 0) { ?>

							<span class="label label-danger"><?=$data_header_status->num_rows()?></span> 

						<?php } ?>
						</a>

                    </li>

                    

                    <li>

                        <a href="javascript:;" data-toggle="collapse" data-target=".katalog_ready"><i class="fa fa-fw fa-list"></i> Katalog Ready Stock <i class="fa fa-fw fa-caret-down"></i></a>

                        <ul katalog_ready class="collapse katalog_ready">

                            <li>

                                  <a href="<?=base_url()?>administrator/main/product/Ready_Stock/Publish/add">Tambahkan Produk <i class="fa fa-fw fa-plus"></i> </a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/product/Ready_Stock/Publish/">Data Produk <span class="label label-success">Publish</span></a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/product/Ready_Stock/Unpublish/">Data Produk <span class="label label-danger">Unpublish</span></a>

                            </li>

                            

                        </ul>

                    </li>

                    <li>

                        <a href="javascript:;" data-toggle="collapse" data-target=".katalog_po"><i class="fa fa-fw fa-list"></i> Katalog Pre Order <i class="fa fa-fw fa-caret-down"></i></a>

                        <ul class="collapse katalog_po">

                            <li>

                                  <a href="<?=base_url()?>administrator/main/product/PO/Publish/add"> Tambahkan Produk <i class="fa fa-fw fa-plus"></i></a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/product/PO/Publish">Data Produk <span class="label label-success">Publish</span></a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/product/PO/Unpublish">Data Produk <span class="label label-danger">Unpublish</span></a>

                            </li>

                            

                        </ul>

                    </li>

                    <li>

                        <a href="javascript:;" data-toggle="collapse" data-target=".data_kategori"><i class="fa fa-fw fa-list"></i> Kategori<i class="fa fa-fw fa-caret-down"></i></a>

                        <ul class="collapse data_kategori">

                             <li>

                                <a href="<?=base_url()?>administrator/main/product_category/add">Tambah Kategori <i class="fa fa-fw fa-plus"></i></span></a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/product_category">Data Kategori</a>

                            </li>

                      

                        </ul>

                    </li>

                    <li>

                        <a href="<?=base_url()?>administrator/main/confirm_payment"><i class="fa fa-fw fa-edit"></i> Konfirmasi Pembayaran</a>

                    </li>

                

                     <li>

                        <a href="javascript:;" data-toggle="collapse" data-target=".pesan"><i class="fa fa-fw fa-edit"></i> Kirim Pesan<i class="fa fa-fw fa-caret-down"></i></a>

                        <ul class="collapse pesan">

                            <li>

                                <a href="<?=base_url()?>administrator/main/message/add">Kirim Pesan</a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/message_to_multiple">Kirim Pesan (Multiple)</span></a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/message">History Pesan</span></a>

                            </li>       

                        </ul>

                    </li>

                    <li>

                        <a href="<?=base_url()?>administrator/main/stock"><i class="fa fa-fw fa-list"></i> Stock</a>

                    </li>
					<li>

                    <a href="<?=base_url()?>administrator/main/master_data_pesanan"><i class="fa fa-fw fa-search"></i> Master Data Pesanan</a>

					</li>

                    <li>

                        <a href="javascript:;" data-toggle="collapse" data-target=".arsip"><i class="fa fa-fw fa-list"></i> Laporan<i class="fa fa-fw fa-caret-down"></i></a>

                        <ul class="collapse arsip">

                            

                            <li>

                                <a href="<?=base_url()?>administrator/main/report_per_day">Laporan Per Hari</span></a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/report_per_month">Laporan Per Bulan</span></a>

                            </li>       

                        </ul>

                    </li>

                    <li>

                        <a href="javascript:;" data-toggle="collapse" data-target=".pengaturan"><i class="fa fa-fw fa-gear"></i> Pengaturan<i class="fa fa-fw fa-caret-down"></i></a>

                        <ul class="collapse pengaturan">

                            <li>

                                <a href="<?=base_url()?>administrator/main/edit_info">Data Toko Online</a>

                            </li>

                            <li>

                                <a href="<?=base_url()?>administrator/main/ekspedisi_jne_prov">Data JNE</span></a>

                            </li>   

							 							

                        </ul>

                    </li>    
					
					<li>

                            <a href="<?=base_url()?>administrator/main/logout"><i class="fa fa-fw fa-power-off"></i> Keluar</a>

                        </li>

                    </ul>

            </div>


            <!-- /.navbar-collapse -->

        </nav>



        <div class="date-wrapper">

            <a href="#"><i class="fa fa-calendar"></i><?= date("D, d-M-Y") ?></a>

        </div>

		