  <?php 
    $data_version = $this->main_model->get_list('data_version_update',array('perpage' => 1,'offset' => 0),array('by' => 'id','sorting' => 'DESC'));
    $data_array_version_last = $data_version->row_array();
    $name_last_vertion = $data_array_version_last['name_version'];
  ?>

		<footer id="footer-container">
			<div class="container-fluid">
               <div class="col-md-6">
               		<div class="links">
			          <small>
					  <b>TokoMobile Ver. <?php echo $name_last_vertion; ?></b><br/>

					  CV. Novatama Infomedia <br/>
					  Phone 021 - 4971 2057 , Mobile 0857 2022 1119 <br/>
					  Email info@tokomobile.co.id <br/>
					  <a href="http://toko-mobile.com" target="_new" >www.tokomobile.co.id</a>
					
					  </small>
					  <br/><br/>
			        </div>
               </div>
               <div class="col-md-6">
               	 <div class="back-top text-right">
               	 	<a href="#top">
                   	 	<i class="fa fa-chevron-circle-up"></i>
                   	 	Back to Top
                   	 </a>
               	 </div>
               </div>  
			</div>
		</footer>
	 </div>
    <!-- /#wrapper -->
    <script src="<?=base_url()?>application/views/administrator/assets/js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?=base_url()?>application/views/administrator/assets/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>application/views/administrator/assets/js/datepicker/js/bootstrap-datepicker.js"></script>
    <!-- Pushy JS -->
    <script src="<?=base_url()?>application/views/administrator/assets/js/pushy.js"></script>

    <script type="text/javascript" src="<?=base_url()?>application/views/administrator/assets/js/jquery-multicomplete.js"></script>
	<script type='text/javascript' src='<?php echo base_url();?>assets/js/jquery.autocomplete.js'></script>
    <!-- Scrollbar JavaScript -->
    <script src="<?=base_url()?>application/views/administrator/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>

    <script src="<?=base_url()?>application/views/administrator/assets/js/custome.js"></script>
    <script type="text/javascript">
      jQuery(document).ready(function ($) {

       $('.search-input').multicomplete({
           minimum_length: 1,
           result_template: function(result, group, matched_field) {
                tmpl = '<div>';
                if(!!result.name_product) {
                    tmpl += '<a href="#">' + result.name_product + '</a>';
                }
                if(!!result.name) {
                    tmpl += '<a href="#">' + result.name + '</a>';
                }
                tmpl += '</div>';
                return tmpl;
           },
           source: '<?=base_url()?>application/views/administrator/includes/demo-source.json'
       }); 
      });
    </script>

    <!-- Morris Charts JavaScript -->
    <script src="<?=base_url()?>application/views/administrator/assets/js/plugins/morris/raphael.min.js"></script>
    <script src="<?=base_url()?>application/views/administrator/assets/js/plugins/morris/morris.min.js"></script>
    <script src="<?=base_url()?>application/views/administrator/assets/js/plugins/morris/morris-data.js"></script>
    <script type="text/javascript">
    $(".fitur_disable").click(function(){
      alert("Fitur tak dapat diakses saat Demo");
    });
    </script>
<!--- AUTO REFRESH --->
		<script type="text/javascript">
		var base_url = '<?=base_url()?>';
		var auto_refresh = setInterval(
		function () {
		$('#load_content').load(base_url+'administrator/main/data_refresh_header').fadeIn("slow");
		}, 20000);
	</script>
	<!--- END AUTO REFRESH --->
</body>

</html>
