<?php include "includes/header.php"; ?>



<!-- Content

================================================== -->

<div id="page-wrapper">



    <div class="container-fluid">

		

	

		<!-- Page Heading -->

	    <div class="row">

	        <div class="col-lg-12">

				

	            <h3>

	                <?=$order_payment?> 

	            </h3>

				<h4>Pesanan Dalam Proses</h4>

	        </div>

	    </div>

	    <!-- /.row -->
		<?=$this->session->flashdata('message') ?>

		<?=form_open('administrator/main/create_keep_order_to_paid'); ?>

		<input type="hidden" name="customer_id" value="<?=$customer_id?>" />

		<table class="table table-bordered">

			<thead>

				<tr class="btn-info">

					<th><br/><input type="checkbox" name="check_all" id="check_all" /></th>
					

					<th>Produk</th>

					<th>Varian</td>

					<th>Qty</th>

					<th>Subtotal</th>

				</tr>

			</thead>

			<tbody>

				

				<?php 

				foreach($orders_item->result() as $items_order): 

				$data_product = $this->main_model->get_detail('product',array('id' => $items_order->prod_id));

				$data_variant = $this->main_model->get_detail('product_variant',array('id' => $items_order->variant_id));

				?>

				<tr>

					<td><input type="checkbox" name="order_item_id[]" class="check_list" value="<?=$items_order->id?>" />
					
					<input type="hidden" name="id_order_item" value="<?=$items_order->id?>">
					
					<td><?=$data_product['name_item']?></td>
					
					<td><?=$data_variant['variant'] ?></td>

					<td><?=$items_order->qty?></td>

					<td>Rp. <?=numberformat($items_order->subtotal)?></td>
					
					<input type="hidden" name="subtotal" value="<?=$items_order->subtotal?>">
					
					<input type="hidden" name="weight" value="<?=$data_product['weight']?>">
					
					<input type="hidden" name="qty" value="<?=$items_order->qty?>">

				</tr>	

				<?php endforeach; ?>

			

			

			</tbody>

		</table>
		
		<button type="submit" class="btn btn-success" name="submit" value="submit">Buat Nota Pesanan</button>
		<button type="submit" class="btn btn-primary" name="submit" value="dropship">Buat Nota Dropship</button>
		

		</form>

		<hr/>

	   	<!-- Page Heading -->

	    <div class="row">

	        <div class="col-lg-12">

				

	            <h4>Data Pesanan</h4>

	        </div>

	    </div>

	    <!-- /.row -->

    

    	

		<?= $output->output; ?>

    </div>



 </div>



<?php include "includes/footer.php"; ?>

<?php if($output->output != null) { ?>

	<?php foreach($output->js_files as $file): ?>

	<script src="<?php echo $file; ?>"></script>

	<?php endforeach; ?>

	<?php } ?>



<script>
$('#check_all').click(function() {    

    		 $('.check_list').prop('checked', this.checked);  

		  if($(this).attr('checked')){

				$('.list').removeAttr('readonly');

			}

			else

			{

				$('.list').attr('readonly','readonly');

			}

 		});
</script>