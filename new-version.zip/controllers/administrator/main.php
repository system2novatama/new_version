<?php



/* 

Class Main 

Author : Tokomobile

Version : 1.2

Last Revision : 26-Okt-2014 

*/





class Main extends CI_Controller {



	Public 

	$tokomobile,
	
	$config_tarif,

	$client_name,

	$package,

	$total_max_product,
	
	$total_max_customer,

	$total_publish_product,
	
	$total_customer,

	$total_available_space_product,
	
	$total_available_space_customer;



	public function __construct()

	{

		parent::__construct();

		$this->check_login();
			
		$this->config_tarif =  $this->config->item('tokomobile_tarif_jne');

		$this->client_name =  $this->config->item('tokomobile_online_shop');

		$this->package =  $this->config->item('tokomobile_package');

		$this->total_max_product = $this->config->item('tokomobile_product_limit');
		
		$this->total_max_customer = $this->config->item('tokomobile_customer_limit');

		$this->total_publish_product = $this->main_model->get_list_where('product',array('status' => 'Publish'))->num_rows();
		
		$this->total_customer = $this->main_model->get_list_where('customer',array('status' => 'Active'))->num_rows();
		
		if($this->total_max_product != 'Unlimited')
		{
			$this->total_available_space_product = $this->total_max_product - $this->total_publish_product;
		}
		else
		{
			$this->total_available_space_product = 'Unlimited';
		}
		
		if($this->total_max_customer != 'Unlimited')
		{
			$this->total_available_space_customer = $this->total_max_customer - $this->total_customer;
		}
		else
		{
			$this->total_available_space_customer = 'Unlimited';
		}
	}

	

	private function check_login()

	{

		if(($this->session->userdata('webadmin_login') == TRUE) and ($this->session->userdata('webadmin_user_id') != null))

		{

			$data_check_user = $this->main_model->get_detail('users',array('id' => $this->session->userdata('webadmin_user_id')));

			$session_pass = $this->session->userdata('webadmin_user_token');

			

			$db_pass= $data_check_user['user_pass'];

			$db_pass_decode = $this->encrypt->decode($db_pass);

			$db_pass_sha1 = sha1($db_pass_decode);

			

			if($session_pass != $db_pass_sha1)

			{

				redirect('administrator/login');

			}

		}

		else

		{

			redirect('administrator/login');

		}

	}

	

	public function index()

	{

		$this->dashboard();

	}

	

	// MENU DASHBOARD

	public function dashboard()

	{

		$data['output'] = null;

		$data['last_order'] = $this->main_model->get_list_where('orders_item',array('order_status' => 'keep'),array('perpage' => 10, 'offset' => 0),array('by' => 'id','sorting' => 'DESC'));

		$data['min_stock_product'] = $this->main_model->get_list('product_variant',null,array('by' => 'stock','sorting' => 'ASC'));

	
		$data['last_chart_date'] = $this->create_chart_date();
		
		$data['last_chart_order'] = $this->create_chart_last_ready();
		
		$data['client_name'] = $this->client_name;
		
		$data['package'] = $this->package;
		
		$data['total_max_product'] = $this->total_max_product;
		
		$data['total_publish_product'] = $this->total_publish_product;
		
		$data['total_available_space_product'] = $this->total_available_space_product;
		
		$data['total_max_customer'] = $this->total_max_customer;
		
		$data['total_customer'] = $this->total_customer;
		
		$data['total_available_space_customer'] = $this->total_available_space_customer;
		

		$this->load->view('administrator/page_main', $data);

	}



	public function create_chart_date()

	{

		$day[0] = date("D, d-M-Y",mktime(0, 0, 0, date("m")  , date("d")-6, date("Y")));	

		$day[1] = date("D, d-M-Y",mktime(0, 0, 0, date("m")  , date("d")-5, date("Y")));

		$day[2] = date("D, d-M-Y",mktime(0, 0, 0, date("m")  , date("d")-4, date("Y")));

		$day[3] = date("D, d-M-Y",mktime(0, 0, 0, date("m")  , date("d")-3, date("Y")));

		$day[4] = date("D, d-M-Y",mktime(0, 0, 0, date("m")  , date("d")-2, date("Y")));

		$day[5] = date("D, d-M-Y",mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")));

		$day[6] = date("D, d-M-Y",mktime(0, 0, 0, date("m")  , date("d"), date("Y")));

		

		$last_day = $day;

		

		return json_encode($last_day);

	} 



	function create_chart_last_ready()

	{

		$table = 'orders_item';

		$field = 'order_datetime';

		

		$day[0] = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-6, date("Y")));	

		$day[1] = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-5, date("Y")));

		$day[2] = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-4, date("Y")));

		$day[3] = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-3, date("Y")));

		$day[4] = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-2, date("Y")));

		$day[5] = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d")-1, date("Y")));

		$day[6] = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")));

		

		$data_day[0] = $this->main_model->get_archive_day($table,$field,$day[0])->num_rows();

		$data_day[1] = $this->main_model->get_archive_day($table,$field,$day[1])->num_rows();

		$data_day[2] = $this->main_model->get_archive_day($table,$field,$day[2])->num_rows();

		$data_day[3] = $this->main_model->get_archive_day($table,$field,$day[3])->num_rows();

		$data_day[4] = $this->main_model->get_archive_day($table,$field,$day[4])->num_rows();

		$data_day[5] = $this->main_model->get_archive_day($table,$field,$day[5])->num_rows();

		$data_day[6] = $this->main_model->get_archive_day($table,$field,$day[6])->num_rows();

		

		return json_encode($data_day);

	}

	

	// MENU PESANAN DALAM PROSES

	function last_order_process()

	{	
		
		$crud = new grocery_CRUD();

		

        $crud->set_table('orders_item')

		->set_subject('Pesanan Terakhir');

		

		$crud->order_by('id','DESC');

		$crud->set_relation('prod_id','product','name_item');

		$crud->set_relation('variant_id','product_variant','variant');

		$crud->unset_fields('order_id');

		$crud->unset_columns('order_id','due_datetime','order_status','order_payment');

		

		$crud->display_as('prod_id','Product')

		->display_as('variant_id','Variant');

		

		$crud->where('order_status','Keep');

		$crud->where('order_payment','Unpaid');

		$crud->add_action('Batalkan', '#', 'administrator/main/cancel_order_process','btn btn-danger btn-crud');	

		$crud->display_as('customer_id','Customer');	
		
		$crud->display_as('order_datetime','Tanggal Order');
		
		$crud->callback_column('customer_id',array($this,'callback_customer_name'));
		

		$crud->unset_add();

		$crud->unset_edit();

		$crud->unset_delete();

		

        $data['output'] = $crud->render();

 

        $this->load->view('administrator/page_last_order',$data);   

	}	

	

	function last_order_product($offset = 0)

	{

		$perpage = 20;

		$data_total = $this->main_model->get_list('product_variant');

		

		$config = array(

					'base_url' => base_url().'administrator/main/last_order_product',

					'per_page' => $perpage,

					'total_rows' => $data_total->num_rows(),

					'uri_segment' => 4

					);

					

		$this->load->library('pagination',$config);		

		

		$data['output'] = null;

		$data['list_product'] = $this->main_model->get_list('product_variant',array('perpage' => $perpage,'offset' => $offset),array('by' => 'id','sorting' => 'DESC'));

		$this->load->view('administrator/page_last_order_product',$data);

	}

	function order_per_product($prod_id = 0)

	{
		$data['product'] =  $this->main_model->get_detail('product',array('id' => $prod_id));
		
		$crud = new grocery_CRUD();


        $crud->set_table('orders_item')

		
		->set_subject('Pesanan dari Produk '.$data['product']['name_item']);

		//$crud->display_as('prod_id','Product');
		
		$crud->order_by('id','DESC');

		//$crud->set_relation('variant_id','product_variant','variant');

		$crud->unset_fields('order_id');

		$crud->unset_columns('order_id','prod_id','due_datetime','order_status','order_payment');

		$crud->where('prod_id',$prod_id);

		$crud->display_as('variant_id','Variant');		

		$crud->display_as('customer_id','Customer');	
		
		$crud->display_as('order_datetime','Tanggal Order');
		
		
		
		$crud->callback_column('customer_id',array($this,'callback_customer_name'));
		
		$crud->callback_column('variant_id',array($this,'callback_variant_name'));
		

		$crud->unset_add();

		$crud->unset_edit();
		
		$crud->unset_operations();

		$crud->unset_delete();

		

        $data['output'] = $crud->render();

 

        $this->load->view('administrator/page_order_per_product',$data);   
		

	}
	

	function cancel_order_process($order_item_id = null)

	{

		$data_order_item = $this->main_model->get_detail('orders_item',array('id' => $order_item_id));

		// Re-stock 

		$data_order_item_product = $this->main_model->get_detail('product_variant',array('id' => $data_order_item['variant_id']));

		$restock = $data_order_item_product['stock'] + $data_order_item['qty'];

		$data_update = array('stock' => $restock);

		$where = array('id' => $data_order_item['variant_id']);

		$this->db->update('product_variant',$data_update,$where);

		

		// Remove order

		$where = array('id' => $order_item_id);

		$this->db->delete('orders_item',$where);

		

		$this->session->set_flashdata('message','<div class="alert alert-success">Pesanan telah dibatalkan</div>');

		redirect('administrator/main/last_order_process');

	}
	
	
	function cancel_order_item($order_item_id = null)

	{

		$data_order_item = $this->main_model->get_detail('orders_item',array('id' => $order_item_id));

		// Re-stock 

		$data_order_item_product = $this->main_model->get_detail('product_variant',array('id' => $data_order_item['variant_id']));

		$restock = $data_order_item_product['stock'] + $data_order_item['qty'];

		$data_update = array('stock' => $restock);

		$where = array('id' => $data_order_item['variant_id']);

		$this->db->update('product_variant',$data_update,$where);

		// GET data weight
		$data_product = $this->main_model->get_detail('product',array('id' => $data_order_item['prod_id']));
		$loss_weight = $data_product['weight'] * $data_order_item['qty'];
		
		// GET Data Order
		$data_order = $this->main_model->get_detail('orders',array('id' => $data_order_item['order_id']));
		
		$new_weight = $data_order['shipping_weight'] - $loss_weight;
		
		if($data_order['order_status'] == 'Dropship')
		{
			// GET Shipping rates
			$ship_rates = $this->main_model->get_detail('jne_tarif',array('kota_tuju_id' => $data_order['kota_id']));

			// Total new Ongkir
			$new_ongkir = ceil($new_weight) * $ship_rates[$this->config_tarif];	
		}
		else{
			$new_ongkir = 0;
		}

		
		// Kurangi Total
		$new_total = ($data_order['total'] - $data_order['shipping_fee']) - $data_order_item['subtotal'] + $new_ongkir ;
		
		// Update order
		$data_update_order = array(
								'shipping_fee' => $new_ongkir,
								'shipping_weight' => $new_weight,
								'total' => $new_total
								);
		$where_order = array('id' => $data_order_item['order_id']);
		$this->db->update('orders',$data_update_order,$where_order);
		
		// Remove order

		$where = array('id' => $order_item_id);

		$this->db->delete('orders_item',$where);

		$this->session->set_flashdata('message','<div class="alert alert-success">Item Pesanan telah dibatalkan</div>');

		redirect('administrator/main/order_detail/'.$data_order_item['order_id']);

	}

	function cancel_order($order_id)
	{
		$this->db->delete('orders',array('id' => $order_id));
		
		$data_orders_item = $this->main_model->get_list_where('orders_item',array('order_id' => $order_id));
		
		foreach($data_orders_item->result() as $orders_item):
		
			$data_order_item_product = $this->main_model->get_detail('product_variant',array('id' => $orders_item->variant_id));

			$restock = $data_order_item_product['stock'] + $orders_item->qty;

			$data_update = array('stock' => $restock);

			$where = array('id' => $orders_item->variant_id);

			$this->db->update('product_variant',$data_update,$where);
			
			$where = array('id' => $orders_item->id);

			$this->db->delete('orders_item',$where);
				
		endforeach;
		
		$this->session->set_flashdata('message','<div class="alert alert-success">Pesanan telah dibatalkan</div>');
		
		redirect('administrator/main/order_all');
	}
	
	function last_order_product_detail($variant_id = null,$offset = 0)

	{

		$data['output'] = null;	

		$perpage = 20;

		$total_pending_order = $this->main_model->get_list_where('orders_item',array('status' => 'keep','variant_id' => $variant_id));

		

		$config = array(

					'base_url' => base_url().'administrator/main/last_order',

					'per_page' => $perpage,

					'total_rows' => $total_pending_order->num_rows(),

					'uri_segment' => 4

					);

		$this->load->library('pagination',$config);			

		$data['last_order'] = $this->main_model->get_list_where('orders_item',array('status' => 'keep','variant_id' => $variant_id),array('perpage' => $perpage, 'offset' => $offset),array('by' => 'id','sorting' => 'DESC'));

		

		$this->load->view('administrator/page_last_order',$data);

	}

	

	function order_all()

	{

		
		$crud = new grocery_CRUD();

		

        $crud->set_table('orders')

		->set_subject('Seluruh Pesanan');

		

		$crud->display_as('id','ID Pesanan');

		$crud->display_as('order_datetime','Tanggal');

		$crud->display_as('shipping_from','From');

		$crud->display_as('shipping_to','To');

		$crud->display_as('order_payment','Status Pembayaran');

		$crud->order_by('id','DESC');

		$crud->columns('id','customer_id','shipping_from','shipping_to','total','order_payment');

		$crud->display_as('customer_id','Customer');	
		
		$crud->callback_column('customer_id',array($this,'callback_customer_name'));

		$crud->add_action('LIHAT', '#', 'administrator/main/order_detail','btn btn-primary btn-crud');

		

		$crud->order_by('id','DESC');

		$crud->unset_texteditor('shipping_from');

		$crud->unset_texteditor('shipping_to');

		$crud->unset_add();

		$crud->callback_column('id',array($this,'customer_id'));

		$crud->unset_edit();
		
		$crud->unset_delete();

        $data['output'] = $crud->render();

		$data['order_payment'] = 'Semua Pesanan';

 

		$this->load->view('administrator/page_order',$data);   

	}

	

	function order_unpaid()

	{

		$crud = new grocery_CRUD();

		

        $crud->set_table('orders')

		->set_subject('Seluruh Pesanan');



		$crud->where('order_payment','Unpaid');

		$crud->display_as('id','ID Pesanan');

		$crud->display_as('order_datetime','Tanggal Order');

		$crud->display_as('shipping_from','From');

		$crud->display_as('shipping_to','To');

		$crud->display_as('order_payment','Status Pembayaran');
		
		$crud->display_as('order_datetime','Tanggal Order'); 

		$crud->order_by('id','DESC');

		$crud->columns('id','customer_id','order_datetime','shipping_from','shipping_to','total','order_payment');

		//$crud->add_action('BATAL', '#', 'administrator/main/order_detail_change_status_list/Paid','btn btn-danger btn-crud');	

		$crud->add_action('JADIKAN LUNAS', '#', 'administrator/main/order_detail_change_status_list/Paid','btn btn-success btn-crud');	
		
		$crud->add_action('LIHAT', '#', 'administrator/main/order_detail','btn btn-primary btn-crud');

		$crud->order_by('id','DESC');

		$crud->unset_texteditor('shipping_from');

		$crud->unset_texteditor('shipping_to');

		$crud->unset_add();
		
		$crud->unset_delete();

		$crud->callback_column('id',array($this,'customer_id'));

		$crud->display_as('customer_id','Customer');	
		
		$crud->callback_column('customer_id',array($this,'callback_customer_name'));

        $data['output'] = $crud->render();

		$data['order_payment'] = 'Belum Lunas';

 

		$this->load->view('administrator/page_order',$data);   

	}

	

	function order_paid()

	{

		$crud = new grocery_CRUD();

		

        $crud->set_table('orders')

		->set_subject('Seluruh Pesanan');



		$crud->where('order_payment','Paid');

		$crud->display_as('id','ID Pesanan');

		$crud->display_as('order_datetime','Tanggal Order');

		$crud->display_as('shipping_from','From');

		$crud->display_as('shipping_to','To');

		$crud->display_as('order_payment','Status Pembayaran');
		
		$crud->display_as('order_status','Jenis Pesanan');

		$crud->order_by('id','DESC');

		$crud->columns('id','customer_id','order_datetime','total','order_payment','order_status');

		$crud->add_action('LIHAT', '#', 'administrator/main/order_detail','btn btn-success btn-crud');

		$crud->order_by('id','DESC');

		$crud->unset_texteditor('shipping_from');

		$crud->unset_texteditor('shipping_to');

		$crud->unset_add();
		
		$crud->unset_delete();

		$crud->callback_column('id',array($this,'customer_id'));

		$crud->display_as('customer_id','Customer');	
		
		$crud->callback_column('customer_id',array($this,'callback_customer_name'));

        $data['output'] = $crud->render();

		$data['order_payment'] = 'Lunas';

 

		$this->load->view('administrator/page_order',$data);   

	}

	

	function order_detail($order_id = null)

	{

		$data_exist = $this->main_model->get_list_where('orders',array('id' => $order_id));
		if($data_exist->num_rows() == 1)
		{
			$data['output'] = null;

			$data['order'] = $this->main_model->get_detail('orders',array('id' => $order_id));

			$data['order_item'] = $this->main_model->get_list_where('orders_item',array('order_id' => $data['order']['id']),null,array('by' => 'id','sorting' => 'ASC'));

			$data['customer'] = $this->main_model->get_detail('customer',array('id' => $data['order']['customer_id'] ));

			$data['provinsi'] = $this->main_model->get_detail('jne_provinsi',array('provinsi_id' => $data['order']['prov_id']));

			$data['kota'] = $this->main_model->get_detail('jne_kota',array('kota_id' => $data['order']['kota_id']));

			$data['jne_tarif'] = $this->main_model->get_detail('jne_tarif',array('kota_tuju_id' => $data['order']['kota_id']));

			

			$this->load->view('administrator/page_order_detail',$data);
		}
		else
		{
			$this->session->set_flashdata('message','<div class="alert alert-warning">Data tidak ditemukan !</div>');
			
			redirect("administrator/main/order_all");
		}	

	}

	

	function order_detail_change_status()

	{

		$order_payment = $this->input->post('order_payment',TRUE);

		$order_id = $this->input->post('order_id',TRUE);

		

		if(($order_payment != null) and ($order_id != null))

		{

			if(($order_payment == 'Unpaid') or ($order_payment == 'Paid'))

			{

				$data_update = array('order_payment' => $order_payment);

				$where = array('id' => $order_id);

				$this->db->update('orders',$data_update,$where);

				

				$this->session->set_flashdata('message','<div class="alert alert-success">Data telah diperbarui !</div>');

			}

			else

			{

				$this->session->set_flashdata('message','<div class="alert alert-error">Data gagal diperbarui !</div>');

			}

		}

		else

		{

			$this->session->set_flashdata('message','<div class="alert alert-error">Data gagal diperbarui !</div>');

		}

		

		redirect('administrator/main/order_detail/'.$order_id);

	}

	

	function order_detail_change_status_list($order_payment = null, $order_id = null)

	{

		if(($order_payment != null) and ($order_id != null))

		{

			if(($order_payment == 'Unpaid') or ($order_payment == 'Paid'))

			{

				$data_update = array('order_payment' => $order_payment);

				$where = array('id' => $order_id);

				$this->db->update('orders',$data_update,$where);

				

				$this->session->set_flashdata('message','<div class="alert alert-success">Status Data Pesanan <strong>#'.$order_id.' </strong> telah diperbarui !</div>');

			}

			else

			{

				$this->session->set_flashdata('message','<div class="alert alert-error">Data gagal diperbarui !</div>');

			}

		}

		else

		{

			$this->session->set_flashdata('message','<div class="alert alert-error">Data gagal diperbarui !</div>');

		}

		

		redirect('administrator/main/order_unpaid');

	}

	function order_detail_update_qty()
	{
		$order_id = $this->input->post('order_id');	
		$order_item_id = $this->input->post('order_item_id');
		$order_item_qty = $this->input->post('order_item_qty');
		
		// Checking available stock
		
		$error_number = 0;
		$error_message = '';
		
		for($i = 0;$i<count($order_item_id);$i++)
	 	{
			$item_id = $order_item_id[$i];
			$item_qty = $order_item_qty[$i];
			
			$data_this_order_item = $this->main_model->get_detail('orders_item',array('id' => $item_id));
			if($item_qty > $data_this_order_item['qty'])
			{
				$selisih_qty = $item_qty - $data_this_order_item['qty'];
				// Check stock
				$this_variant = $this->main_model->get_detail('product_variant',array('id' => $data_this_order_item['variant_id']));
				$this_product = $this->main_model->get_detail('product',array('id' => $data_this_order_item['prod_id']));
				if($this_variant['stock'] < $selisih_qty)
				{
					$error_number++;
					$error_message .= '<div class="alert alert-danger">Produk <b>'.$this_product['name_item'].'</b> Variant <b>'.$this_variant['variant'].'</b> Tidak memiliki Stock yang cukup untuk dipesan </div>';
					
				}
			}
			
		}
		
		if($error_number == 0)
		{
			$new_total = 0;
			$new_total_weight = 0;
		 	for($i = 0;$i<count($order_item_id);$i++)
		 	{
				$item_id = $order_item_id[$i];
				$item_qty = $order_item_qty[$i];
				
				$data_this_order_item = $this->main_model->get_detail('orders_item',array('id' => $item_id));
				$data_this_product = $this->main_model->get_detail('product',array('id' => $data_this_order_item['prod_id']));
				$data_this_variant = $this->main_model->get_detail('product_variant',array('id' => $data_this_order_item['variant_id']));
				
				// Update stock
				$selisih_qty = $item_qty - $data_this_order_item['qty'];
				$new_stock = $data_this_variant['stock'] - $selisih_qty;
				$data_update_stock = array('stock' => $new_stock);
				$where_stock = array('id' => $data_this_order_item['variant_id']);
				$this->db->update('product_variant',$data_update_stock,$where_stock);
				
				
				$this_subtotal = $data_this_order_item['price'] * $item_qty;
				
				$data_update = array(
								'qty' => $item_qty,
								'subtotal' => $this_subtotal
								);
				$where = array('id' => $item_id);
								
				$this->db->update('orders_item',$data_update,$where);				
				
				$new_total = $new_total + $this_subtotal;
				
				$this_weight = $data_this_product['weight'] * $item_qty;				
				$new_total_weight = $new_total_weight + $this_weight;
			}
			
			// Update Data Order
			
			$data_this_order = $this->main_model->get_detail('orders',array('id' => $order_id));
			
			// Data ship_rates
			
			if($data_this_order['order_status'] == 'Dropship')
			{
				$data_this_rates = $this->main_model->get_detail('jne_tarif',array('kota_tuju_id' => $data_this_order['kota_id']));
				$new_shipping_fee = ceil($new_total_weight) * $data_this_rates[$this->config_tarif];
			}
			else
			{
				$new_shipping_fee = 0;
			}	
			
			$new_total = $new_total + $new_shipping_fee;
		
			$data_update_order = array(
									'shipping_fee' => $new_shipping_fee,
									'shipping_weight' => $new_total_weight,
									'total' => $new_total
									);
			$where = array('id' => $order_id);						
			$this->db->update('orders',$data_update_order,$where);
			
			$this->session->set_flashdata('message','<div class="alert alert-success">Data Item pesanan telah diperbarui !</div>');
		}
		else
		{
			$this->session->set_flashdata('message',$error_message);
		}	
		
		redirect('administrator/main/order_detail/'.$order_id);												
	}

	function order_detail_add_product()
	{
		$order_id = $this->input->post('add_form_order_id');
		$prod_id = $this->input->post('add_form_product');
		$variant_id = $this->input->post('add_form_variant');
		$qty = $this->input->post('add_form_qty');
		
		// Get data
		$data_product = $this->main_model->get_detail('product',array('id' => $prod_id));
		$data_variant = $this->main_model->get_detail('product_variant',array('id' => $variant_id));
		$data_order = $this->main_model->get_detail('orders',array('id' => $order_id));
		
		if($data_order['order_status'] == 'Dropship')
		{
			$data_jne_tarif = $this->main_model->get_detail('jne_tarif',array('kota_tuju_id' => $data_order['kota_id']));	
		}
		
		
		if($qty <= $data_variant['stock'])
		{
			// Pre defined data
			$subtotal = $data_product['price'] * $qty;
			$total_weight_this_product = $data_product['weight'] * $qty;
			$total_weight_this_order = $data_order['shipping_weight'] + $total_weight_this_product;
			if($data_order['order_status'] == 'Dropship')
			{
				$total_shipping_fee = ceil($total_weight_this_order) * $data_jne_tarif[$this->config_tarif];
			}
			else
			{
				$total_shipping_fee = 0;
			}	
			$total_shop = ($data_order['total'] - $data_order['shipping_fee']) + $subtotal;
			$total = $total_shop + $total_shipping_fee;
			
			// add order_item
			$data_insert = array(
								'customer_id' => $data_order['customer_id'],
								'order_id' => $order_id,
								'prod_id' => $prod_id,
								'order_datetime' => date('Y-m-d H:i:s'),
								'variant_id' => $variant_id,
								'qty' => $qty,
								'price' => $data_product['price'],
								'subtotal' => $subtotal,
								'tipe' => $data_product['product_type'],
								'order_status' => $data_order['order_status'],
								'order_payment' => $data_order['order_payment']
								);
			
			$this->db->insert('orders_item',$data_insert);
			
			//update stock
			$new_stock = $data_variant['stock'] - $qty;
			$data_update_stock = array('stock' => $new_stock);
			$where_update_stock = array('id' => $variant_id);
			$this->db->update('product_variant',$data_update_stock,$where_update_stock);										
			
			// Update data Order
			$data_update_order = array(
									'shipping_weight' => $total_weight_this_order,
									'shipping_fee' => $total_shipping_fee,
									'total' => $total
									);
			$where_order = array('id' => $order_id);
			$this->db->update('orders',$data_update_order,$where_order);
			
			$this->session->set_flashdata('message','<div class="alert alert-success">Item Pesanan telah ditambahkan</div>');
		}
		else
		{
			$this->session->set_flashdata('message','<div class="alert alert-danger">Produk <b>'.$data_product['name_item'].'</b> Variant <b>'.$data_variant['variant'].'</b> Tidak memiliki Stock yang cukup untuk dipesan </div>');
		}
		
		redirect('administrator/main/order_detail/'.$order_id);											
	}
	
	function order_detail_get_publish_product()
	{
		$data_publish_product = $this->main_model->get_list_where('product',array('status' => 'Publish'));
		
		foreach($data_publish_product->result() as $products):
			$data_json[] = array(
								'prod_id' => $products->id,
								'name_item' => $products->name_item
							);
		endforeach;
		
		echo json_encode($data_json);
	}
	
	function order_detail_get_variant()
	{
		$prod_id = $this->input->post('prod_id');
			
		$data_variant = $this->main_model->get_list_where('product_variant',array('prod_id' => $prod_id));
		
		foreach($data_variant->result() as $variants):
			$data_json[] = array(
								'variant_id' => $variants->id,
								'variant' => $variants->variant
							);
		endforeach;
		
		echo json_encode($data_json);
	}
	
	function order_detail_get_variant_detail()
	{
		$variant_id = $this->input->post('variant_id');
			
		$data_variant = $this->main_model->get_detail('product_variant',array('id' => $variant_id));
		
		$data_json = $data_variant;
		
		echo json_encode($data_json);
	}
	
	function nota_detail_print($order_id = null)

	{

		$data['orders'] = $this->main_model->get_detail('orders',array('id' => $order_id));

		$data['customer'] = $this->main_model->get_detail('customer',array('id' => $data['orders']['customer_id'] ));

		$data['orders_item'] = $this->main_model->get_list_where('orders_item',array('order_id' => $order_id));

		$data['total'] = $data['orders']['total'];

		$data['url_redirect'] = base_url()."administrator/main/order_detail/".$order_id;

		

		$this->load->view('administrator/print/print_nota',$data);

	}

	

	function ekspedisi_print($order_id = null)

	{

		$data['data_orders'] = $this->main_model->get_detail('orders',array('id' => $order_id));

		$data['customer'] = $this->main_model->get_detail('customer',array('id' => $data['data_orders']['customer_id'] ));

		$data['orders_item'] = $this->main_model->get_list_where('orders_item',array('order_id' => $order_id));

		$data['total'] = $data['data_orders']['total'];

		$data['url_redirect'] = base_url()."administrator/main";



		$this->load->view('administrator/print/print_ekspedisi',$data);

	}

	

	function ekspedisi_print_a4($order_id = null)

	{

		$data['data_orders'] = $this->main_model->get_detail('orders',array('id' => $order_id));

		$data['customer'] = $this->main_model->get_detail('customer',array('id' => $data['data_orders']['customer_id'] ));

		$data['orders_item'] = $this->main_model->get_list_where('orders_item',array('order_id' => $order_id));

		$data['total'] = $data['data_orders']['total'];

		$data['url_redirect'] = base_url()."administrator/main/order_detail/".$order_id;

		

		$this->load->view('administrator/print/print_ekspedisi_a4',$data);

	}

	

	function create_order()

	{

		$data['output'] = null;	

		$data['customer'] = $this->main_model->get_list_where('customer',array('status' => 'Active'));

		$data['product'] = $this->main_model->get_list_where('product',array('status' => 'Publish'));

		

		$this->load->view('administrator/page_new_order',$data);

	}


	function create_order_tamu()

	{

		$data['output'] = null;
		$data['product'] = $this->main_model->get_list_where('product',array('status' => 'Publish'));

		

		$this->load->view('administrator/page_new_order_tamu',$data);

	}

	

	function get_variant_create_order()

	{

		$prod_id = $this->input->post('prod_id');

		

		$data_product = $this->main_model->get_detail('product',array('id' => $prod_id));

		$data_variant = $this->main_model->get_list_where('product_variant',array('prod_id' => $prod_id));

		

		foreach($data_variant->result() as $variant): 

			$data_json_variant[] = array('variant_id' => $variant->id, 'variant_name' => $variant->variant, 'stock' => $variant->stock);

		endforeach;

		

		$data_json = array(

						'prod_id' => $data_product['id'],

						'price' => $data_product['price'],

						'weight' => $data_product['weight'],

						'variant' => $data_json_variant

						);



		echo json_encode($data_json);

		

	}

	

	function create_order_process()

	{

		$this->form_validation->set_rules('customer_id','Customer','required');

		$customer_id = $this->input->post('customer_id');

		if ($customer_id = 0) {
			
			$name_customer = $this->input->post('name_customer');
			$phone_customer = $this->input->post('phone_customer');
			$address_customer = $this->input->post('address_customer');
		}

		$check = $this->input->post('check_list');

		$product = $this->input->post('product');

		$variant = $this->input->post('variant');

		$price = $this->input->post('price');

		$qty = $this->input->post('qty');

		$subtotal = $this->input->post('subtotal');
		
		$subtotal_weight = $this->input->post('subtotal_weight');

		$status_pesanan = $this->input->post('status_pesanan');

		$redirect = 'administrator/main/create_order';


		if($this->form_validation->run() == TRUE)

		{

			// Check error stock
			$error_number = 0;
			$error_message = '';
			for($i=0;$i<count($check);$i++)
			{
				$this_check = $check[$i];

				$data_product = $this->main_model->get_detail('product',array('id' => $product[$this_check]));
				$data_variant = $this->main_model->get_detail('product_variant',array('id' => $variant[$this_check]));	
	
				if($qty[$this_check] > $data_variant['stock'])
				{
					$error_number++;
					$error_message .= '<div class="alert alert-danger">Produk <b>'.$data_product['name_item'].'</b> Variant <b>'.$data_variant['variant'].'</b> Tidak memiliki Stock yang cukup untuk dipesan </div>';
				}
			}


			if($error_number == 0)
			{
				// Status Pesanan
			if(($status_pesanan == 'Keep_Paid') or ($status_pesanan == 'Dropship_Unpaid') or ($status_pesanan == 'Dropship_Paid'))
			{
				
				if ($customer_id == 0) {
					// Data pesanan
					$data_order = array(

								'customer_id' => $this->input->post('customer_id'),
								'name_customer' => $this->input->post('name_customer'),
								'phone_customer' => $this->input->post('phone_customer'),
								'address_customer'=> $this->input->post('address_customer'),

								'order_datetime' => date('Y-m-d H:i:s'),

								'shipping_fee' => 0,

								'shipping_weight' => 0,

								'shipping_from' => "",

								'shipping_to' => "",

								'prov_id' => 0,

								'kota_id' => 0,

								'total' => 0

					);
				} else {
				// Data pesanan

				$data_order = array(

								'customer_id' => $this->input->post('customer_id'),

								'order_datetime' => date('Y-m-d H:i:s'),

								'shipping_fee' => 0,

								'shipping_weight' => 0,

								'shipping_from' => "",

								'shipping_to' => "",

								'prov_id' => 0,

								'kota_id' => 0,

								'total' => 0
					);
				}
								

				if($status_pesanan == 'Keep_Paid')

				{

					$data_order['order_status'] = 'Keep';

					$data_order['order_payment'] = 'Paid';
					

				}

				elseif($status_pesanan == 'Dropship_Unpaid')

				{

					$data_order['order_status'] = 'Dropship';

					$data_order['order_payment'] = 'Unpaid';
					
					

				}

				elseif($status_pesanan == 'Dropship_Paid')

				{

					$data_order['order_status'] = 'Dropship';

					$data_order['order_payment'] = 'Paid';
					
					

				}	

				

				$this->db->insert('orders',$data_order);

				$order_id = mysql_insert_id();
				
				if(($status_pesanan == 'Dropship_Unpaid') or ($status_pesanan == 'Dropship_Unpaid'))
				{
					$redirect = 'administrator/main/create_order_dropship/'.$order_id.'/unpaid';
				}
				else
				{
					$redirect = 'administrator/main/create_order';
				}

			}

			else

			{

				$order_id = 0;

				$data_order['order_status'] = 'Keep';

				$data_order['order_payment'] = 'Unpaid';
				
				$redirect = 'administrator/main/create_order';
			}

			//Orders Item

			$grand_total = 0;
			$total_weight = 0;
			
			for($i=0;$i<count($check);$i++)

			{

				$this_check = $check[$i];

				$data_product = $this->main_model->get_detail('product',array('id' => $product[$this_check]));
				$data_variant = $this->main_model->get_detail('product_variant',array('id' => $variant[$this_check]));

				$data_order_item = array(

								'customer_id' => $this->input->post('customer_id'),

								'order_id' => $order_id,

								'prod_id' => $product[$this_check],

								'order_datetime' => date('Y-m-d H:i:s'),

								'variant_id' => $variant[$this_check],

								'qty' => $qty[$this_check],

								'price' => $price[$this_check],

								'subtotal' => $subtotal[$this_check],

								'order_status' => $data_order['order_status'],

								'order_payment' => $data_order['order_payment']

								);

								
				$this->db->insert('orders_item',$data_order_item);
				
				// Update stock
				$new_stock = $data_variant['stock'] - $qty[$this_check];
				$data_update_stock = array('stock' => $new_stock);
				$where_variant = array('id' => $variant[$this_check]);
				$this->db->update('product_variant',$data_update_stock,$where_variant);
				
				$grand_total = $grand_total +  $subtotal[$this_check];
				$total_weight = $total_weight + $subtotal_weight[$this_check];

			}
			
			if($order_id != 0)
			{
				$data_update_order = array('total' => $grand_total, 'shipping_weight' => $total_weight);
				$where = array('id' => $order_id);
				
				$this->db->update('orders',$data_update_order,$where);
			}

			$this->session->set_flashdata('message','<div class="alert alert-success">Pesanan telah ditambahkan dengan Status Pesanan <b>'.get_order_status($data_order['order_status']).'</b> dan status Pembayaran <b>'.get_order_payment($data_order['order_payment']).'</b></div>');

		
			}
			else
			{
				$this->session->set_flashdata('message',$error_message);
			}
			
		}	

		else

		{

			$this->session->set_flashdata('message','<div class="alert alert-danger">Customer belum dipilih</div>');

		}
		
		redirect($redirect);

	}
	
	function order_keep_to_dropship($id = null)
	{
		
	}

	function create_order_dropship($order_id = null, $status = null)
	{
		$data['output'] = null;	
		if(($order_id != null) and ($status != null))
		{
			$data['provinsi'] = $this->main_model->get_list('jne_provinsi');
			$data['orders'] = $this->main_model->get_detail('orders',array('id' => $order_id));
			$data['orders_item'] = $this->main_model->get_list_where('orders_item',array('order_id' => $order_id));
			$data['customer'] = $this->main_model->get_detail('customer',array('id' => $data['orders']['customer_id']));
			
			$data['total_belanja'] = 0;
			foreach($data['orders_item']->result() as $items):
				$data['total_belanja'] = $data['total_belanja'] + $items->subtotal;
			endforeach;
			
			$this->load->view('administrator/page_create_order_dropship',$data);
		}
	}
	

	function create_order_dropship_process()
	{
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
		$this->form_validation->set_rules('order_id','Order ID','required');
		$this->form_validation->set_rules('shipping_from','Pengirim','required');
		$this->form_validation->set_rules('shipping_to','Kepada','required');
		$this->form_validation->set_rules('prov_id','Provinsi','required');
		$this->form_validation->set_rules('kota_id','Kota','required');
		$this->form_validation->set_rules('shipping_fee','Ongkos Kirim','required');
		$this->form_validation->set_rules('total_after','Total','required');
		
		if($this->form_validation->run() == TRUE)
		{
			$data_update = array(
								'shipping_from' => $this->input->post('shipping_from'),
								'shipping_to' => $this->input->post('shipping_to'),
								'shipping_fee' => $this->input->post('shipping_fee'),
								'prov_id' => $this->input->post('prov_id'),
								'kota_id' => $this->input->post('kota_id'),
								'total' => $this->input->post('total_after')
								);
			
			$where = array('id' => $this->input->post('order_id'));	
			$this->db->update('orders',$data_update,$where);
			
			$this->session->set_flashdata('message','<div class="alert alert-success">Pesanan telah disimpan</div>');
			redirect('administrator/main/order_detail/'.$this->input->post('order_id'));
		}
		else
		{
			$data['output'] = null;	
			$data['provinsi'] = $this->main_model->get_list('jne_provinsi');
			$data['orders'] = $this->main_model->get_detail('orders',array('id' => $this->input->post('order_id')));
			$data['orders_item'] = $this->main_model->get_list_where('orders_item',array('order_id' => $this->input->post('order_id')));
			$data['customer'] = $this->main_model->get_detail('customer',array('id' => $data['orders']['customer_id']));
			
			$data['total_belanja'] = 0;
			foreach($data['orders_item']->result() as $items):
				$data['total_belanja'] = $data['total_belanja'] + $items->subtotal;
			endforeach;
			
			$this->load->view('administrator/page_create_order_dropship',$data);
		}
	}

	function get_kota()

	{

		$prov_id = $this->input->post('prov_id');

		$data_kota = $this->main_model->get_list_where('jne_kota',array('kota_prov_id' => $prov_id));

		foreach($data_kota->result() as $list_kota):

			$list_json[] = array('kota_id' => $list_kota->kota_id,'kota_nama' => $list_kota->kota_nama);

		endforeach; 

		if($data_kota->num_rows() > 0)

		{

			$data_json = array('status' => 'Success','list' => $list_json);

		}

		else

		{

			$data_json = array('status' => 'Failed');

		}

		

		echo json_encode($data_json);

	}

	

	function get_shipping_fee()

	{

		$kota_id = $this->input->post('kota_id');

		

		$data_tarif = $this->main_model->get_list_where('jne_tarif',array('kota_tuju_id' => $kota_id));

		

		if($data_tarif->num_rows() > 0)

		{

			$data_tarif = $data_tarif->row_array();

			$data_json = array('status' => 'Success','tarif' => $data_tarif[$this->config_tarif]);

		}

		else

		{

			$data_json = array('status' => 'Failed');

		}

		

		echo json_encode($data_json);

	}

	

	function create_keep_order_to_paid() //Buat Nota Pesanan

	{
		if($this->input->post('submit') == "submit")
		{

		$data['output'] = null;

		$order_item_id = $this->input->post('order_item_id');

		$customer_id =  $this->input->post('customer_id');

		if($order_item_id > 0)
		
		{
			$data_insert = array(

								'customer_id' => $customer_id,

								'order_datetime' => date('Y-m-d H:i:s'),

								'order_status' => 'Keep',

								'order_payment' => 'Paid'

								);

								

			$this->db->insert('orders',$data_insert);	



			$order_id = mysql_insert_id();

			

			$total = 0;

			for($i = 0;$i < count($order_item_id); $i++)

			{

				$data_update = array('order_id' => $order_id,'order_payment' => 'Paid');

				$where = array('id' => $order_item_id[$i]);

				$this->db->update('orders_item',$data_update,$where);

				$data_orders_item = $this->main_model->get_detail('orders_item',array('id' => $order_item_id[$i]));

				$total = $total + $data_orders_item['subtotal'];

			}

			

			$data_update_order = array('total' => $total);

			$where_order = array('id' => $order_id);

			$this->db->update('orders',$data_update_order,$where_order);	

			

			$data['total'] = $total;

			

			// Ambil data yg telah disimpan

			$data['orders'] = $this->main_model->get_detail('orders',array('id' => $order_id));

			$data['customer'] = $this->main_model->get_detail('customer',array('id' => $customer_id));

			$data['orders_item'] = $this->main_model->get_list_where('orders_item',array('order_id' => $order_id));

			

			$this->session->set_flashdata('message','<div class="alert alert-success">Data Pesanan telah dibuat</div>');
			
			redirect('administrator/main/order_detail/'.$order_id);

		}
		else
		{
			$this->session->set_flashdata('message','<div class="alert alert-danger">Tidak ada Item pesanan dipilih</div>');
			
			redirect('administrator/main/order_per_customer/'.$customer_id);
		}
		}
		else
		{
			$check = $this->input->post('check_list');
			
			$customer_id =  $this->input->post('customer_id');
			
			$order_item_id = $this->input->post('order_item_id');
			
			$weight = $this->input->post('weight');
			
			$qty = $this->input->post('qty');
			
			$total_weight = 0;
			
			for($i = 0;$i < count($order_item_idf); $i++)
			{
				$total_weight =  $total_weight + ($weight*$qty);
			}
			
			
			$id_order_item =  $this->input->post('id_order_item');
			
			$subtotal =  $this->input->post('subtotal');
			
			if($order_item_id > 0)
		
			{	
			
			
				$data_order = array(

								'customer_id' => $this->input->post('customer_id'),

								'order_datetime' => date('Y-m-d H:i:s'),

								'shipping_fee' => 0,

								'shipping_weight' => $total_weight,

								'shipping_from' => "",

								'shipping_to' => "",

								'prov_id' => 0,

								'kota_id' => 0,
								
								'order_status' => "Dropship",

								'total' => 0
					);
				$this->db->insert('orders',$data_order);
				$order_id = mysql_insert_id();
				
			for($i = 0;$i < count($order_item_id); $i++)
			{
				$data_update = array('order_status' => "Dropship",'order_id' => $order_id);

				$where = array('id' => $order_item_id[$i]);

				$this->db->update('orders_item',$data_update,$where);
			}
			
			redirect('administrator/main/create_order_dropship/'.$order_id.'/unpaid');
				
			}
		else
		{
			$this->session->set_flashdata('message','<div class="alert alert-danger">Tidak ada Item pesanan dipilih</div>');
			
			redirect('administrator/main/order_per_customer/'.$customer_id);
		}
		}
		

	}

	

	// MENU PELANGGAN //

	function customer()

	{

		$crud = new grocery_CRUD();

		

        $crud->set_table('customer')

		->set_subject('Customer');

		

		$crud

		->display_as('id','Customer ID')

		->display_as('kota_id','Kota')

		->display_as('prov_id','Provinsi');

		

		$crud->order_by('id','DESC');

		$crud->columns('id','name','email','status','update_status');

		$crud->fields('name','email','password','address','prov_id','kota_id','postcode','phone','status','update_status');

		$crud->set_relation('prov_id','jne_provinsi','provinsi_nama');

		$crud->set_relation('kota_id','jne_kota','kota_nama');

		$crud->unset_texteditor('address');

		

		$crud->add_action('Edit', '#', 'administrator/main/customer/edit','btn btn-info btn-crud');

		$crud->add_action('Lihat Pesanan', '#', 'administrator/main/order_per_customer','btn btn-primary btn-crud');

		

		$crud->callback_before_insert(array($this,'encrypt_password_customer'));

    	$crud->callback_before_update(array($this,'encrypt_password_customer'));

		$crud->callback_edit_field('password',array($this,'decrypt_password_customer'));

		$crud->callback_delete(array($this,'callback_delete_customer'));
		
		$crud->callback_column('update_status',array($this,'callback_customer_status'));

		
		if($this->total_available_space_customer == 0)  {
				$crud->unset_add();
				$crud->unset_edit();
		}

        $output = $crud->render();

        $this->get_customer_list($output); 

	}	

	

	function order_per_customer($customer_id = null)

	{

		$crud = new grocery_CRUD();

		

        $crud->set_table('orders')

		->set_subject('Seluruh Pesanan');

		

		if($customer_id > 0)

		{

			$data_customer = $this->main_model->get_detail('customer',array('id' => $customer_id));

			$crud->where('customer_id',$customer_id);

		}

		

		$crud->display_as('id','ID Pesanan');

		$crud->display_as('order_datetime','Tanggal');

		$crud->display_as('shipping_from','From');

		$crud->display_as('shipping_to','To');

		$crud->display_as('order_payment','Status Pembayaran');

		$crud->order_by('id','DESC');

		$crud->columns('id','customer_id','shipping_from','shipping_to','total','order_payment');



		$crud->add_action('LIHAT', '#', 'administrator/main/order_detail','btn btn-primary btn-crud');

		

		$crud->order_by('id','DESC');

		$crud->unset_texteditor('shipping_from');

		$crud->unset_texteditor('shipping_to');

		$crud->unset_add();

		$crud->callback_column('id',array($this,'customer_id'));

		

		$crud->unset_edit();

		

        $data['output'] = $crud->render();

		$data['order_payment'] = 'Semua Pesanan dari Customer ID '.$customer_id.' ('.$data_customer['name'].')';

		$data['orders_item'] = $this->main_model->get_list_where('orders_item',array('customer_id' => $customer_id,'order_status' => 'Keep','order_payment' => 'Unpaid'),null,array('by' => 'id','sorting' => 'DESC'));

		$data['customer_id'] = $customer_id;

 

		$this->load->view('administrator/page_order_customer',$data);

	}	

	

	// MENU KATALOG PRODUK

	function product($product_type = 'Ready_Stock', $status = 'Publish')

	{

		if($product_type == 'Ready_Stock')

		{

			$product_type_label = 'Ready Stock';

		}

		else

		{

			$product_type_label = $product_type;

		}

	

		$crud = new grocery_CRUD();

		

        $crud->set_table('product')

		->set_subject('Products');



		$this->config->set_item('grocery_crud_file_upload_allow_file_types','gif|jpeg|jpg|png');

		$crud->order_by('id','DESC');

		$crud->where('status',$status);

		$crud->where('product_type',$product_type_label);

		$crud->columns('datetime','name_item','category_id','price','image');

		$crud->fields('datetime','name_item','product_type','category_id','price_production','price','weight','description','min_order','upload_image','image','variant');
		
		$crud->display_as('datetime','Tanggal')
		->display_as('name_item','Nama Item')
		->display_as('category_id','Kategori')
		->display_as('price_production','Harga Modal')
		->display_as('price','Harga Jual')
		->display_as('weight','Berat')
		->display_as('description','Deskripsi')
		->display_as('min_order','Minimal Order');

		$crud->change_field_type('product_type','hidden', $product_type_label);

		$crud->change_field_type('datetime','hidden',date("Y-m-d H:i:s"));

		$crud->set_relation('category_id','product_category','name',array('tipe' => $product_type_label));

		$crud->set_field_upload('image','media/images/original');

		$crud->unset_texteditor('description');

		$crud->callback_column('image',array($this,'thumbnailer'));

		$crud->callback_field('variant',array($this,'callback_add_product'));

		$crud->callback_edit_field('variant',array($this,'callback_edit_product'));

		$crud->callback_before_insert(array($this,'callback_before_add_product'));
		
		$crud->callback_after_insert(array($this,'callback_after_add_product'));

		$crud->callback_before_update(array($this,'callback_before_edit_product'));	
		
		$crud->callback_after_update(array($this,'callback_after_edit_product'));
		
		$crud->callback_before_upload(array($this,'image_callback_before_upload'));

		$crud->callback_after_upload(array($this,'image_callback_after_upload'));
		
		$crud->callback_delete(array($this,'callback_delete_product'));
		
		$crud->callback_add_field('upload_image',array($this,'callback_add_field_img_product'));
		$crud->callback_edit_field('upload_image',array($this,'callback_add_field_img_product'));
			
		$crud->required_fields('name_item','category_id','weight','price_production','price','min_order','image','status');	
	
		$crud->add_action('Order', '#', 'administrator/main/order_per_product/','btn btn-success btn-crud');
			
		if($status == 'Publish')

		{

			$crud->add_action('Unpublish', '#', 'administrator/main/update_status_product/'.$product_type.'/Unpublish','btn btn-danger btn-crud');

		}

		else

		{

			$crud->add_action('Publish', '#', 'administrator/main/update_status_product/'.$product_type.'/Publish','btn btn-success btn-crud');

		}

		

		$crud->add_action('Edit', '#', 'administrator/main/product/'.$product_type.'/'.$status.'/edit','btn btn-primary btn-crud');	

		if ($product_type == 'Ready_Stock' && $status == 'Publish' ) {
			$crud->add_action('to PO', '#', 'administrator/main/update_to_pre_order','btn btn-info btn-crud');
		} elseif ($product_type == 'PO' && $status == 'Publish' ) {
			$crud->add_action('to Ready Stock', '#', 'administrator/main/update_to_ready_stock','btn btn-info btn-crud');

		}

		$crud->unset_read();

		
		if($this->total_available_space_product == 0)
		{
				$crud->unset_add();
		}

		

		$output = $crud->render();

		$this->get_product_list($output); 

	}

	function update_to_ready_stock($prod_id = null)
	{
		$data_update = array('product_type' => 'Ready Stock');

		$where = array('id' => $prod_id);

		$this->db->update('product',$data_update,$where);

		$this->session->set_flashdata('message','<div class="alert alert-success">Product telah diubah ke Product Ready Stock</div>');

		redirect('administrator/main/product/PO/Publish/');
	}


	function update_to_pre_order($prod_id = null)
	{
		$data_update = array('product_type' => 'PO');

		$where = array('id' => $prod_id);

		$this->db->update('product',$data_update,$where);

		$this->session->set_flashdata('message','<div class="alert alert-success">Product telah diubah ke Product Pre Order</div>');

		redirect('administrator/main/product/Ready_Stock/Publish/');
	}

	function update_status_product($product_type = 'Ready_Stock', $status = null, $prod_id = null)

	{

		$data_update = array('status' => $status);

		$where = array('id' => $prod_id);

		

		$this->db->update('product',$data_update,$where);

		

		if($status == 'Publish')

		{

			$this->session->set_flashdata('message','<div class="alert alert-success">Product telah di Publish</div>');

			if($product_type == 'Ready_Stock')

			{

				redirect('administrator/main/product/Ready_Stock/Unpublish/');

			}

			else

			{

				redirect('administrator/main/product/PO/Unpublish/');

			}

			

		}

		elseif($status == 'Unpublish')

		{

			$this->session->set_flashdata('message','<div class="alert alert-warning">Product telah di Unpublish</div>');

			if($product_type == 'Ready_Stock')

			{

				redirect('administrator/main/product/Ready_Stock/Publish/');

			}

			else

			{

				redirect('administrator/main/product/PO/Publish/');

			}

		}	

	}



	function product_category()

	{

		$crud = new grocery_CRUD();

		

        $crud->set_table('product_category')

		->set_subject('Product Category');


		$crud->add_action('Edit', '#', 'administrator/main/product_category/edit','btn btn-primary btn-crud');

		$crud->add_action('View', '#', 'administrator/main/product_category/read','btn btn-info btn-crud');



        $output = $crud->render();

        $this->get_product_category($output); 

	}

	

	function confirm_payment()

	{

		$crud = new grocery_CRUD();

		

        $crud->set_table('confirmation')

		->set_subject('Konfirmasi Pembayaran');


		$crud->add_action('Lihat Detail', '#', 'administrator/main/confirm_payment_detail','btn btn-info btn-crud');


		$crud->unset_delete();

		$crud->unset_read();

		$crud->display_as('customer_id','Customer');	
		
		$crud->callback_column('customer_id',array($this,'callback_customer_name'));

        $output = $crud->render();
 

        $this->get_confirm_payment($output); 

	}

	

	function confirm_payment_detail($confirmation_id = null)

	{

		$data['output'] = null;

		$data['confirmation'] = $this->main_model->get_detail('confirmation',array('id' => $confirmation_id));

		$data['confirmation_order']  = $this->main_model->get_detail('orders',array('id' => $data['confirmation']['order_id']));

		

		$this->load->view('administrator/page_confirm_payment_detail',$data);

		

	}

	

	function confirm_payment_change_status($confirmation_id = null, $status = null, $order_payment = null)

	{

		if($confirmation_id > 0)

		{

			$data_confirmation = $this->main_model->get_detail('confirmation',array('id' => $confirmation_id));

			$data_update_confirmation = array('status' => $status);

			$where_confirmation = array('id' => $confirmation_id);

			

			$this->db->update('confirmation',$data_update_confirmation,$where_confirmation);



			if($order_payment == 'Paid')

			{

				if($data_confirmation['order_id'] > 0)

				{

					$data_update_order = array('order_payment' => 'Paid');

					$where_order = array('id' => $data_confirmation['order_id']);

					$this->db->update('orders',$data_update_order,$where_order);

					

					$this->session->set_flashdata('message','<div class="alert alert-success">Data Konfirmasi telah di Approve dan Pesanan #'.$data_confirmation['order_id'].' telah LUNAS</div>');

				}

				else

				{

					$this->session->set_flashdata('message','<div class="alert alert-warning">Data Konfirmasi telah di Approve</div>');

				}

			}

			else

			{

				$this->session->set_flashdata('message','<div class="alert alert-warning">Data Konfirmasi telah di Reject</div>');

			}

			

			redirect('administrator/main/confirm_payment_detail/'.$confirmation_id);

		}

		else

		{

			$this->session->set_flashdata('message','<div class="alert alert-warning">Data Konfirmasi tidak ditemukan</div>');

			redirect('administrator/main/confirm_payment');

		}

	}	

	

	// PESAN

	function message()

	{

		$crud = new grocery_CRUD();

		

        $crud->set_table('message')

		->set_subject('Message');



		$crud->add_action('Delete', '#', 'administrator/main/message/delete','delete-row btn btn-danger btn-crud');

		$crud->add_action('Edit', '#', 'administrator/main/message/edit','btn btn-primary btn-crud');	

		$crud->add_action('View', '#', 'administrator/main/message/read','btn btn-info btn-crud');

		$crud->display_as('customer_id','Customer');
		
		$crud->callback_column('customer_id',array($this,'callback_customer_name'));
		
		$crud->set_relation('customer_id','customer','name');

		$crud->unset_texteditor('content');

		$crud->unset_fields('status');

		$crud->order_by('id','DESC');

		

        $output = $crud->render();

 

        $this->get_message_list($output); 

	}

	

	function message_to_multiple()

	{

		$data['output'] = null;	

		$data['list_customer'] = $this->main_model->get_list('customer');	

		$this->load->view('administrator/page_message_multiple',$data);

	}

	

	function message_to_multiple_process()

	{

		$subject = $this->input->post('subject');

		$content = $this->input->post('content');

		$customer_id = $this->input->post('customer_id');

		

		for($i=0;$i<count($customer_id);$i++)

		{

			$data_insert = array(

							'customer_id' => $customer_id[$i],

							'subject' => $subject,

							'content' => $content

							);

			$this->db->insert('message',$data_insert);				

		}

		

		$this->session->set_flashdata('message','<div class="alert alert-success">Pesan telah dikirim</div>');

		

		redirect('administrator/main/message_to_multiple');

	}

	

	

	function stock($offset = 0)

	{

		$data['output'] = null;
		$data_total = $this->main_model->get_list('product_variant');
		$perpage = 10;
		$this->load->library('pagination');
		$config = array (
					'base_url' => base_url().'administrator/main/stock',
					'per_page' => $perpage,
					'total_rows' => $data_total->num_rows(),
					'uri_segment' => 4 
					);
						
		$this->pagination->initialize($config);
		$data['offset'] = $offset;
		$data['perpage'] = $perpage;
		$data['list_item'] = $this->main_model->get_list('product_variant',array('perpage' => $perpage, 'offset' => $offset),array('by' => 'id', 'sorting' => 'DESC'));
		$this->load->view('administrator/page_stock',$data);

	}

	

	function stock_update()

	{

		$items_id = $this->input->post('item_id');

		$stock = $this->input->post('stock');

		

		for($i = 0; $i < count($items_id); $i++)

		{

			$data_items = $this->main_model->get_detail('product_variant',array('id' => $items_id[$i]));

			

			if( ($stock[$i] != null) and (is_numeric($stock[$i]) == 1) )

			{

				$stock_new = $data_items['stock'] + $stock[$i];

				

				$data_update = array('stock' => $stock_new);

				$where = array('id' => $items_id[$i]);

				$this->db->update('product_variant',$data_update,$where);

			}	

		}

		

		$this->session->set_flashdata('message','<div class="alert alert-success">Data Stock Telah di Update</div>');

		

		redirect('administrator/main/stock');

	}

	

	function users()

	{

		$crud = new grocery_CRUD();

		

        $crud->set_table('users')

		->set_subject('users');

		

		$crud->set_field_upload('image','media/images');

		

		$crud->field_type('user_pass','password');

		

		$crud->callback_before_insert(array($this,'encrypt_password'));

    	$crud->callback_before_update(array($this,'encrypt_password'));

		$crud->callback_edit_field('user_pass',array($this,'decrypt_password'));

		

        $output = $crud->render();

 

        $this->get_output($output);  

	}

	

	function report_per_day()

	{

		$data['output'] = null;

		$this->load->view('administrator/page_report_per_day',$data);

	}

	

	function report_per_day_process()

	{

		$data['output'] = null;

		$date = $this->input->post('date');

		

		$data['this_date'] = $date;

		

		$query_clause = "SELECT * FROM orders WHERE DATE_FORMAT(order_datetime,'%Y-%m-%d') = '$date' AND order_payment = 'Paid' ";

		$query = $this->db->query($query_clause);

		

		$data['transaksi'] = $query;

		

		$this->load->view('administrator/page_report_per_day_result',$data);

	}

	

	function report_per_day_print()

	{

		$data['output'] = null;

		$date = $this->input->post('date');

		

		$data['this_date'] = $date;

		

		$query_clause = "SELECT * FROM orders WHERE DATE_FORMAT(order_datetime,'%Y-%m-%d') = '$date' AND order_payment = 'Paid' ";

		$query = $this->db->query($query_clause);

		

		$data['transaksi'] = $query;

		

		$this->load->view('administrator/page_report_per_day_print',$data);

	}

	

	function report_per_month()

	{

		$data['output'] = null;

		$this->load->view('administrator/page_report_per_month',$data);

	}

	

	function report_per_month_process()

	{

		$data['output'] = null;

		$month = $this->input->post('month');

		

		$data['this_month'] = $month;

		

		$query_clause = "SELECT * FROM orders WHERE DATE_FORMAT(order_datetime,'%Y-%m') = '$month' AND order_payment = 'Paid'";

		$query = $this->db->query($query_clause);

		

		$data['transaksi'] = $query;

		

		$this->load->view('administrator/page_report_per_month_result',$data);

	}

	

	function report_per_month_print()

	{

		$data['output'] = null;

		$month = $this->input->post('month');

		

		$data['this_month'] = $month;

		

		$query_clause = "SELECT * FROM orders WHERE DATE_FORMAT(order_datetime,'%Y-%m') = '$month' AND order_payment = 'Paid' ";

		$query = $this->db->query($query_clause);

		

		$data['transaksi'] = $query;

		

		$this->load->view('administrator/page_report_per_month_print',$data);

	}

	

	function ekspedisi_jne_prov()

	{
		$data['prov'] = null;
		$data['kota'] = null;
		$crud = new grocery_CRUD();

        $crud->set_table('jne_provinsi')

		->set_subject('Data Provinsi');
		$crud->columns('provinsi_nama');
		$crud->add_action('Edit', '#', 'administrator/main/ekspedisi_jne_prov/edit','btn btn-primary btn-crud');	
		$crud->add_action('Daftar Kota', '#', 'administrator/main/ekspedisi_jne_kota','btn btn-primary btn-crud');	
		$crud->unset_add();
	
        $output = $crud->render();

        $data['output'] = $output;

		$this->load->view('administrator/page_jne_list',$data);  

	}
	
	
	function ekspedisi_jne_kota($prov_id = 1)

	{
		$data['prov'] = $this->main_model->get_detail('jne_provinsi',array('provinsi_id' => $prov_id));
		$data['kota'] = null;

		$crud = new grocery_CRUD();

	
        $crud->set_table('jne_kota')

		->set_subject('Data Kota di Provinsi <b>'.$data['prov']['provinsi_nama'].'</b>');
		
		$crud->columns('kota_nama');
		$crud->fields('kota_id','kota_nama','kota_prov_id');
		
		$crud->add_action('Edit', '#', 'administrator/main/ekspedisi_jne_kota/'.$prov_id.'/edit','btn btn-primary btn-crud');	
		//$crud->add_action('Daftar Kecamatan', '#', 'administrator/main/ekspedisi_jne','btn btn-primary btn-crud');	
		$crud->where('kota_prov_id',$prov_id);
		$crud->change_field_type('kota_prov_id','hidden',$prov_id);
		$crud->change_field_type('kota_id','hidden');

		$crud->callback_add_field('kota_nama', array($this,"callback_add_field_jne"));
		$crud->callback_before_insert(array($this,'callback_before_insert_jne'));
		
		$crud->callback_edit_field('kota_nama', array($this,"callback_edit_field_jne"));
		$crud->callback_before_update(array($this,'callback_before_update_jne'));

        $output = $crud->render();

        $data['output'] = $output;

		$this->load->view('administrator/page_jne_list',$data);  

	}
	
	function callback_add_field_jne()
	{
		return '<input type="text" maxlength="50" value="" name="kota_nama"><br/>Tarif<br/><input type="text" maxlength="50" value="" name="tarif" />';
	}
	
	function callback_edit_field_jne($value,$primary_key)
	{
		$data_tarif = $this->main_model->get_detail('jne_tarif',array('kota_tuju_id' => $primary_key));
				
		return '<input type="text" maxlength="50" value="'.$value.'" name="kota_nama"><br/>Tarif<br/><input type="text" maxlength="50" value="'.$data_tarif['reg'].'" name="tarif" />';
		
	}
	
	function callback_before_insert_jne($post_array)
    {
    	$this->db->select_max('kota_id');
		$data_max_jne = $this->db->get('jne_kota')->row_array();
		
		$primary_key = $data_max_jne['kota_id'] + 1;
		
		$post_array['kota_id'] = $primary_key;
		
		// get_data_tarif 
		$this->db->select_max('tarif_id');
		$data_max_tarif = $this->db->get('jne_tarif')->row_array();
		$primary_key_tarif = $data_max_tarif['tarif_id'] + 1;
		
		// get_data asal
		$data_jne = $this->main_model->get_list('jne_tarif')->row_array();
		
		// Insert to data Tarif
		$data_insert_tarif = array(
								'tarif_id' => $primary_key_tarif,
								'prov_asal_id' => $data_jne['prov_asal_id'],
								'kota_asal_id' => $data_jne['kota_asal_id'],
								'prov_tuju_id' => $post_array['kota_prov_id'],
								'kota_tuju_id' => $primary_key,
								'reg' => $post_array['tarif']
								);
								
		$this->db->insert('jne_tarif',$data_insert_tarif);
		
		return $post_array;
	}
	
	function callback_before_update_jne($post_array)
    {
		
		// Insert to data Tarif
		$data_update_tarif = array(
								'reg' => $post_array['tarif']
								);
		
		$where = array('kota_tuju_id' => $post_array['kota_id']);
								
		$this->db->update('jne_tarif',$data_update_tarif,$where);
		
		return $post_array;
	}
	
	function ekspedisi_jne($kota_id = 1)
	{
		$data['kota'] = $this->main_model->get_detail('jne_kota',array('kota_id' => $kota_id));
		$data['prov'] = $this->main_model->get_detail('jne_provinsi',array('provinsi_id' => $data['kota']['kota_prov_id']));
		

		$crud = new grocery_CRUD();

        $crud->set_table('jne_tarif')

		->set_subject('Tarif JNE untuk Kota <b>'.$data['kota']['kota_nama'].'</b>');

		$crud->where('kota_tuju_id',$kota_id);

	

		$crud->display_as('prov_asal_id','Provinsi Asal');

		$crud->display_as('kota_asal_id','Kota Asal');

		$crud->display_as('prov_tuju_id','Provinsi Tujuan');

		$crud->display_as('kota_tuju_id','Kota Tujuan');

		$crud->display_as('reg','Tarif (REG)');

		

		$crud->columns('tarif_id','kecamatan','reg');

		$crud->fields('kecamatan','prov_asal_id','kota_asal_id','prov_tuju_id','kota_tuju_id','reg');

		$crud->change_field_type('prov_asal_id','hidden',6);
		
		$crud->change_field_type('kota_asal_id','hidden',93);
		
		$crud->change_field_type('prov_tuju_id','hidden',$data['kota']['kota_prov_id']);
		
		$crud->change_field_type('kota_tuju_id','hidden',$kota_id);
		
		$crud->add_action('Edit', '#', 'administrator/main/ekspedisi_jne/'.$kota_id.'/edit','btn btn-primary btn-crud');	

		$crud->add_action('View', '#', 'administrator/main/ekspedisi_jne/'.$kota_id.'/read','btn btn-info btn-crud');

		
		$crud->set_field_upload('category_image','media/images');

	
		$crud->field_type('user_pass','password');


		$crud->callback_before_insert(array($this,'encrypt_password'));

    	$crud->callback_before_update(array($this,'encrypt_password'));

		$crud->callback_edit_field('user_pass',array($this,'decrypt_password'));

		

        $output = $crud->render();


        $data['output'] = $output;

		$this->load->view('administrator/page_jne_list',$data);  

	}




	function edit_profile()

	{

		$data['output'] = null;

		$this->load->view('administrator/page_edit_profile',$data);

	}


	function update_vertion()

	{

		$data['output'] = null;
		$data_version_last = $this->main_model->get_list('data_version_update',array('perpage' => 1,'offset' => 0),array('by' => 'id','sorting' => 'DESC'));
		$data_array_version_last = $data_version_last->row_array();
		$name_version_last = $data_array_version_last['name_version'];
		$name_version_new = $name_version_last + 0.1;
		$number_new_vertion = $name_version_new * 10;
		
		$data_new_version = array(
								
								'name_version' => $name_version_new,
								'date' => date("Y-m-d"),
								'status' => 'active',
								'number_version ' => $number_new_vertion,
							);

		$this->db->insert('data_version_update',$data_new_version);

		$this->session->set_flashdata('message','<div class="alert alert-success">Anda Telah Berhasil Melakukan Update Versi Yang Baru </div>');
		
		redirect('administrator/main');

	}

	

	function edit_profile_process()

	{

		$data['output'] = null;

		$this->form_validation->set_error_delimiters('<div class="alert alert-error">', '</div>');

		$this->form_validation->set_rules('user_email','Email','required');

		$this->form_validation->set_rules('user_name','Username','required');

		

		$this_user = $this->main_model->get_list_where('users',array('user_name' => $this->input->post('user_name')));

		

		if($this->form_validation->run() === TRUE)

		{

			$data_update = array(

							'user_email' => $this->input->post('user_email'),

							'user_name' => $this->input->post('user_name')

							);

			

			if(($this->input->post('user_pass') != null) or ($this->input->post('user_pass') != '') )

			{

				$data_update['user_pass'] = $this->encrypt->encode($this->input->post('user_pass'));

			}

			

			$where = array('id' => $this->session->userdata('webadmin_user_id'));

			$this->db->update('users',$data_update,$where);

			

			$this->session->set_flashdata('message','<div class="alert alert-success">Data telah di update</div>');

			redirect('administrator/main/edit_profile');			

		}

		else

		{

			$this->load->view('administrator/page_edit_profile',$data);

		}	

	}



	

	

	function edit_info()

	{

		$data['output'] = null;

		$this->load->view('administrator/page_edit_info',$data);

	}

	

	

	function edit_info_process()

	{

		$data['output'] = null;

		$this->form_validation->set_error_delimiters('<div class="alert alert-error">', '</div>');

		$this->form_validation->set_rules('info_kontak','Info Kontak','required');

		$this->form_validation->set_rules('info_rekening','Info Rekening','required');

		$this->form_validation->set_rules('info_nota','Info Nota','required');
		


		

		if($this->form_validation->run() === TRUE)

		{

		
		
			// Update info rekening

			$data_update = array('value' => $this->input->post('info_rekening'));

			$where = array('id' => 1);

			$this->db->update('content',$data_update,$where);	

			

			// Update info kontak

			$data_update = array('value' => $this->input->post('info_kontak'));

			$where = array('id' => 2);

			$this->db->update('content',$data_update,$where);	

			

			// Update info kontak

			$data_update = array('value' => $this->input->post('info_nota'));

			$where = array('id' => 3);

			$this->db->update('content',$data_update,$where);	
			
			
			
			// Link Android

			
			$data_update = array('value' => $this->input->post('link_android'));

			$where = array('name' => 'link_android');

			$this->db->update('content',$data_update,$where);	
			
			
			// Link Blackberry
			
			
			$data_update = array('value' => $this->input->post('link_blackberry'));

			$where = array('name' => 'link_blackberry');

			$this->db->update('content',$data_update,$where);	
			
			

			$this->session->set_flashdata('message','<div class="alert alert-success">Data telah di update</div>');

			redirect('administrator/main/edit_info');	

		}

		else

		{

			$this->load->view('administrator/page_edit_info',$data);

		}	

	}

	// FUNCTION BARUU //
	function update_status_data_pelanggan($id)
	{
		$data=$this->main_model->get_detail('customer',array('id' => $id));
		$status=$data['status'];
		if($status == 'Active')
		{
			$data=array('status'=>'Inactive');
			$where=array('id'=>$id);
			$this->main_model->update_status_data_pelanggan('customer',$data,$where);
		}
		else if($status == 'Moderate')
		{
			$data=array('status'=>'Active');
			$where=array('id'=>$id);
			$this->main_model->update_status_data_pelanggan('customer',$data,$where);
		}
		else if($status == 'Inactive')
		{
			$data=array('status'=>'Moderate');
			$where=array('id'=>$id);
			$this->main_model->update_status_data_pelanggan('customer',$data,$where);
		}
		redirect('administrator/main/customer');
	}
	public function data_refresh_header()
	{
		$data['data_header_order_unpaid'] = $this->main_model->get_list_where('orders',array('order_payment' => 'Unpaid'),null,array('by' => 'id','sorting' => 'DESC'));

		$data['data_header_order_process'] = $this->main_model->get_list_where('orders_item',array('order_status' => 'Keep', 'order_payment' => 'Unpaid'),null,array('by' => 'id','sorting' => 'DESC'));

		$data['data_header_confirmation'] =  $this->main_model->get_list_where('confirmation',array('status' => 'Pending'),null,array('by' => 'id','sorting' => 'DESC'));
		
		$data['data_header_status'] =  $this->main_model->get_list_where('customer',array('status' => 'Moderate'),null,array('by' => 'id','sorting' => 'DESC'));

		$this->load->view('administrator/includes/header_ajax',$data);
	}
	public function search_id_customer($query)
	{
	
		// cari di database
		$this->db->select('id,name');
		$this->db->from('customer');
		$this->db->like('name',$query);
		$data = $this->db->get();
		$arr=array();
		// format keluaran di dalam array
		foreach($data->result() as $row)
		{
			$arr['query'] = $query;
			$arr['suggestions'][] = array(
				'value'	=>$row->name,
				'data'	=>$row->id
			);
		}
		// minimal PHP 5.2
		echo json_encode($arr);
	}

	function search_product_stock(){

		$data['output'] = null;

		$word = $this->input->post('prod_id');

		$int_value = intval($word);

		
		$search_name = $this->main_model->get_detail('product',array('id'=> $int_value));

		$data['placeholder_pro'] = $search_name;
		$data['list_stock'] = $this->main_model->get_list_where('product_variant',array('prod_id' =>$int_value), null,array('by' => 'id', 'sorting' => 'DESC'));

		$this->load->view('administrator/page_search_stock', $data);
		
	}


	function search_category_stock(){

		$data['output'] = null;

		$word = $this->input->post('cat_id');

		$int_value = intval($word);

		
		$search_name = $this->main_model->get_detail('product_category',array('id'=> $int_value));

		$data['placeholder_cat'] = $search_name;
		$data['list_stock'] = $this->main_model->get_list_where('product_variant',array('category_id' =>$int_value), null,array('by' => 'id', 'sorting' => 'DESC'));

		$this->load->view('administrator/page_search_stock', $data);
		
	}


	public function search_product_id($query)
	{
	
		// cari di database
		$this->db->select('id,name_item');
		$this->db->from('product');
		$this->db->like('name_item',$query);
		$data = $this->db->get();
		$arr=array();
		// format keluaran di dalam array
		foreach($data->result() as $row)
		{
			$arr['query'] = $query;
			$arr['suggestions'][] = array(
				'value'	=>$row->name_item,
				'data'	=>$row->id
			);
		}
		// minimal PHP 5.2
		echo json_encode($arr);
	}

	public function search_category_id($query)
	{
	
		// cari di database
		$this->db->select('id,name');
		$this->db->from('product_category');
		$this->db->like('name',$query);
		$data = $this->db->get();
		$arr=array();
		// format keluaran di dalam array
		foreach($data->result() as $row)
		{
			$arr['query'] = $query;
			$arr['suggestions'][] = array(
				'value'	=>$row->name,
				'data'	=>$row->id
			);
		}
		// minimal PHP 5.2
		echo json_encode($arr);
	}
	
	public function search_id_produk_item($query)
	{
		// cari di database
		$this->db->select('id,name_item');
		$this->db->from('product');
		$this->db->like('name_item',$query);
		$data = $this->db->get();
		$arr=array();
		// format keluaran di dalam array
		foreach($data->result() as $row)
		{
			$arr['query'] = $query;
			$arr['suggestions'][] = array(
				'value'	=>$row->name_item,
				'data'	=>$row->id
			);
		}
		// minimal PHP 5.2
		echo json_encode($arr);
	}
	function master_data_pesanan()
	{
		$data['customer'] = $this->main_model->get_list_where('customer',array('status' => 'Active'));

		$data['product'] = $this->main_model->get_list_where('product',array('status' => 'Publish'));
		
		$name = $this->input->post('customer_id');
		
		$bayar = $this->input->post('status_pembayaran');
		
		$pesan = $this->input->post('status_pesanan');
		
		$pro = $this->input->post('product_id');
		
		$cari = $this->input->post('cari');
		
		$date_awal = $this->input->post('date_awal');
		
		$date_akhir = $this->input->post('date_akhir');
		
		
		{
			if($cari != '' )
			{
				$crud = new grocery_CRUD();

				$crud->set_table('orders_item')
	
				->set_subject('Pesanan Filter');
				
				if($pesan!="all")
				{
					$crud->where('order_status',$pesan);
				}
				if($name!=null)
				{
					$crud->where('customer_id',$name);
				}
				if($bayar!="all")
				{
					$crud->where('order_payment',$bayar);
				}
				if($pro!=null)
				{
					$crud->where('orders_item.prod_id',$pro);
				}
				if($date_awal!=null && $date_akhir!=null )
				{
					$date_awal1 = $date_awal." 00:00:01";
					$date_akhir1 = $date_akhir." 23:59:59";
					$crud->where('order_datetime >=',$date_awal1);
					$crud->where('order_datetime <=',$date_akhir1);
				}
				
				$crud->order_by('id','DESC');

				$crud->set_relation('prod_id','product','name_item');
				
				$crud->set_relation('customer_id','customer','name');

				$crud->set_relation('variant_id','product_variant','variant');

				$crud->unset_fields('order_id');

				$crud->unset_columns('order_id','due_datetime','tipe','price','ref','actions');

				$crud->display_as('customer_id','Customer');	
				
				$crud->display_as('prod_id','Product');	
				
				$crud->display_as('variant_id','Variant');	
		
				$crud->display_as('order_datetime','Tanggal Order');
		
				$crud->callback_column('customer_id',array($this,'callback_customer_name'));
		

				$crud->unset_add();

				$crud->unset_edit();

				$crud->unset_delete();
				
				$crud->columns('order_datetime','customer_id','prod_id','variant_id','qty','subtotal','order_status','order_payment');
				
				$data['output'] = $crud->render();
				
				$data['arr'] = array(
									'customer_name' => $this->input->post('customer_name'),
									'customer_id' =>$name,
									'product_name' =>$this->input->post('product_name'),
									'status_pembayaran' =>$bayar,
									'status_pesanan' =>$pesan,
									'date_awal' =>$date_awal,
									'date_akhir' =>$date_akhir
									);
				
				$this->load->view('administrator/page_master_data_pesanan',$data); 
			}
			
						else
							{
								$data['output'] = null;
							
								$this->load->view('administrator/page_master_data_pesanan',$data);  
							}
		}
	}
	function get_version()
	{
		$data_version_now = $this->main_model->get_list('data_version_update',array('perpage' => 1,'offset' => 0),array('by' => 'id','sorting' => 'DESC'));
		$data_version = $data_version_now->row_array();
		
			$version_now = array(
								'id' => $data_version['id'],
								'version_now' => $data_version['name_version'],
								'version_number' => $data_version['number_version'],
								'date' => $data_version['date']
							);

		
		echo json_encode($version_now);
	}
	// END FUNCTION BARUU //
	

	// MENU KELUAR //	

	public function logout()

	{

		$this->load->library('auth');

		$this->auth->logout();

	}

	

	//-------- CALLBACK OR OTHER FUNCTION BEGIN HERE ------//

	

	public function get_output($output = null)

	{

		$data['output'] = $output;

		$this->load->view('administrator/page_crud',$data);    

	}



	public function get_dropship_ready($output = null)

	{

		$data['output'] = $output;

		$this->load->view('administrator/page_dropship_ready',$data);    

	}



	public function get_customer_list($output = null)

	{

		$data['output'] = $output;

		$this->load->view('administrator/page_customer_list',$data);    

	}



	public function get_product_list($output = null)

	{

		$data['output'] = $output;

		$this->load->view('administrator/page_product_list',$data);    

	}



	public function get_product_category($output = null)

	{

		$data['output'] = $output;

		$this->load->view('administrator/page_product_category',$data);    

	}



	public function get_confirm_payment($output = null)

	{

		$data['output'] = $output;

		$this->load->view('administrator/page_confirm_payment',$data);    

	}



	public function get_message_list($output = null)

	{

		$data['output'] = $output;

		$this->load->view('administrator/page_message_list',$data);    

	}



	public function get_nota_list($output = null)

	{

		$data['output'] = $output;

		$this->load->view('administrator/page_nota_list',$data);    

	}



	public function get_jne_list($output = null)

	{

		$data['output'] = $output;

		$this->load->view('administrator/page_jne_list',$data);    

	}

	

	public function thumbnailer($value,$row)

	{

		return "<img src='".base_url()."media/images/medium/".$value."' width='75' />";

	}

	public function callback_customer_name($value, $row)
	{
		$data_customer = $this->main_model->get_detail('customer',array('id' => $value));	
	  	
		if ($value != 0) {

			return $data_customer['name']." (".$data_customer['id'].")";
		}
	}
	
	public function callback_variant_name($value, $row)
	{
		$data_variant = $this->main_model->get_detail('product_variant',array('id' => $value));	
	  	
		return $data_variant['variant'];
	}
	
	function callback_add_field_img_product()
	{
		return 'Gunakan Button dibawah ini untuk mengunggah Gambar. Note : hindari penggunaan karakter <strong>Plus</strong> + , <strong>Kurung</strong> () , dan  <strong>Koma</strong> pada nama File Gambar Anda, agar Gambar dapat disimpan dengan Baik.';
	}

	public function encrypt_password($post_array, $primary_key = null)

	{

    	$post_array['user_pass'] = $this->encrypt->encode($post_array['user_pass']);

    	return $post_array;

	}

 

	public function decrypt_password($value)

	{

    	$decrypted_password = $this->encrypt->decode($value);

   		return "<input type='password' name='user_pass' value='$decrypted_password' />";

	}

	

	public function encrypt_password_customer($post_array, $primary_key = null)

	{

    	$post_array['password'] = $this->encrypt->encode($post_array['password']);

    	return $post_array;

	}

 

	public function decrypt_password_customer($value)

	{

    	$decrypted_password = $this->encrypt->decode($value);

   		return "<input type='text' name='password' value='$decrypted_password' />";

	}

	

	function insert_date_story($post_array,$primary_key)

	{

		$insert_date = array('datetime' => strtotime('now'));

		$where = array('id' => $primary_key);

 

		$this->db->update('member_story',$insert_date,$where);

	

		return true;

	}

	

	function column_change_datetime($value, $row)

	{

		 return date('D, d M Y',$row->datetime);

	}	



	function field_change_datetime($value ='', $primary_key = null)

	{

		 return date('D, d M Y',$value);

	}		



	public function _callback_webpage_url($value, $row)

	{

		return "00".$row->id;

	}



	function view_order($order_id = null)

	{

		if($order_id != null)

		{

			$data['order'] = $this->main_model->get_detail('orders',array('id' => $order_id));

			$data['order_item'] = $this->main_model->get_list_where('rel_prod_orders',array('order_id' => $order_id));

			$data['customer'] = $this->main_model->get_detail('customer',array('id' => $data['order']['customer_id']));

			$data['output'] = null;

			

			$this->load->view('administrator/view_order_detail',$data);

		}

	}

	

	function change_status_order($status = null, $order_id = null)

	{

		if( ($status != null) and ($order_id != null) )

		{

			$data_update = array('status' => $status);

								

			$where = array('id' => $order_id);

			$this->db->update('orders',$data_update,$where);

			$this->session->set_flashdata('message','<div class="alert alert-success">Order status has change "PAID" </div>');	

			redirect('administrator/main/view_order/'.$order_id);

		}

	}

	

	function callback_add_product()

	{

		$return_add = '	<br/>

					<div class="well">

					<table cellpadding="10px" width="500px">

					<thead>

						<tr>

							<th>Check !</th>

							<th>Variant</th>

							<th>Stock</th>

						</tr>

					</thead>

					<tbody>'

					;

		for($i=0;$i<10;$i++)

		{

			$return_add .= '<tr>

								<td><input type="checkbox" class="form-control check_list" name="check_variant[]" onclick="check_variant()" value="'.$i.'"/></td>

								<td><input type="text" style="width:200px;" class="form-control" id="variant_name_'.$i.'" name="variant_name[]" /></td>

								<td><input type="number" style="width:150px;" class="form-control" id="stock_'.$i.'" name="stock[]" min="0"/></td>

							</tr>

							

							';

		}



		$return_add .= '</tbody></table></div>';

		return $return_add;

	}

	function callback_before_add_product($post_array) {
			
			// Char_replace
			$char = array(',',';','*','!','@','#','$','%','^','&','(',')','+','}','{','[',']','--','---');
			$replace = "-";
			$new_name = str_replace($char,$replace,$post_array['image']);
	
			// Char_replace name item
			$new_name_item = str_replace('-','_',$post_array['name_item']);
			$post_array['name_item'] = $new_name_item;
	
			$post_array['image'] = $new_name;
	 
			return $post_array;
	}        

	function callback_after_add_product($post_array,$primary_key)

	{

		$check = $post_array['check_variant'];

		$variant = $post_array['variant_name'];

		$stock = $post_array['stock'];

		$category = $post_array['category_id'];



		for($i=0;$i<count($check);$i++)

		{

			$check_id = $check[$i];

			$data_insert = array(

								'prod_id' => $primary_key,

								'variant' => $variant[$check_id],

								'category_id' => $category,

								'stock' => $stock[$check_id]

								);

			

			$this->db->insert('product_variant',$data_insert);

		}	

		return true;

	}

	

	function callback_edit_product($value,$primary_key)

	{

		$data_variant = $this->main_model->get_list_where('product_variant',array('prod_id' => $primary_key));

		$return_edit = '	
		<br/>

					<div class="well">			

					<table cellpadding="10px" width="500px">

					<thead>

						<tr>

							<th>Check !</th>

							<th>Variant</th>

							<th>Stock</th>

						</tr>

					</thead>

					<tbody>'

					;

		foreach($data_variant->result() as $variant) :

			$return_edit .= '<tr>

								<td><input type="checkbox" class="form-control"  name="update_check_variant['.$variant->id.']" checked="checked" value="'.$variant->id.'"/><input type="hidden" name="update_variant_id[]" value="'.$variant->id.'" /></td>

								<td><input type="text" style="width:200px;" class="form-control" value="'.$variant->variant.'" name="update_variant_name['.$variant->id.']" /></td>

								<td><input type="number" style="width:150px;"class="form-control"  value="'.$variant->stock.'" name="update_stock['.$variant->id.']" min="0"/></td>

							</tr>';

		endforeach;

		

		$field_nol = 10 - $data_variant->num_rows();

		for($i=0;$i<$field_nol;$i++)

		{

			$return_edit .= '<tr>

								<td><input type="checkbox" class="form-control check_list" name="check_variant[]" onclick="check_variant()" value="'.$i.'"/></td>

								<td><input type="text" style="width:200px;" class="form-control" id="variant_name_'.$i.'" name="variant_name[]" /></td>

								<td><input type="number" style="width:150px;" class="form-control" id="stock_'.$i.'" name="stock[]" min="0"/></td>

							</tr>	

							';

		}

		

		$return_edit .= '</tbody></table></div>';

		

		return $return_edit;

	}

	function callback_before_edit_product($post_array) 
	{		
			// Char_replace image
			$char = array(',',';','*','!','@','#','$','%','^','&','(',')','+','}','{','[',']','--','---');
			$replace = "-";
			$new_image = str_replace($char,$replace,$post_array['image']);
			$new_image = str_replace('-.','.',$new_image);
		
			// Check data image OLD
			$data_old = $this->main_model->get_detail('product',array('id' => $post_array['id']));
			if($data_old['image'] != $post_array['image'])
			{
				$post_array['image'] = $new_image;
			}
			
			// Char_replace name item
			$new_name_item = str_replace('-','_',$post_array['name_item']);
			$post_array['name_item'] = $new_name_item;
	
			
	
			return $post_array;
	}        
	
	function callback_after_edit_product($post_array,$primary_key)
	{

		// Parameter Edit

		$update_variant_id = $post_array['update_variant_id'];

		$update_check= $post_array['update_check_variant'];

		$update_variant = $post_array['update_variant_name'];

		$update_stock = $post_array['update_stock'];

		$category = $post_array['category_id'];

	

		// Parameter Add

		$check = $post_array['check_variant'];

		$variant = $post_array['variant_name'];

		$stock = $post_array['stock'];

		

		// Update or Delete

		for($i=0;$i<count($update_variant_id);$i++)

		{

			$update_check_id = $update_variant_id[$i];

			$where = array('id' => $update_check_id);

			

			if($update_check[$update_check_id])

			{

				$data_update = array(

									'prod_id' => $primary_key,

									'variant' => $update_variant[$update_check_id],

									'stock' => $update_stock[$update_check_id],
									'category_id' => $category
									);

									

				$this->db->update('product_variant',$data_update,$where);

			}

			else

			{

				$this->db->delete('product_variant',$where);

			}	

		}

		

		// Add 

		for($i=0;$i<count($check);$i++)

		{

			$check_id = $check[$i];

			$data_insert = array(

								'prod_id' => $primary_key,

								'variant' => $variant[$check_id],

								'stock' => $stock[$check_id],
								'category_id' => $category

								);

			

			$this->db->insert('product_variant',$data_insert);

		}	

		

		return true;

	}

	public function callback_delete_product($primary_key)
	{
		// Delete image product
		$data_product = $this->main_model->get_detail('product',array('id' => $primary_key));
		
		unlink(PUBPATH.'media/images/original/'.$data_product['image']);
		unlink(PUBPATH.'media/images/thumb/'.$data_product['image']);
		unlink(PUBPATH.'media/images/medium/'.$data_product['image']);
		unlink(PUBPATH.'media/images/large/'.$data_product['image']);
		
		return $this->db->update('product',array('status' => 'Delete'),array('id' => $primary_key));
	}	
	
	public function callback_delete_customer($primary_key)
	{
		// Delete all order of this member
		$this->db->delete('orders',array('customer_id' => $primary_key));
		$this->db->delete('orders_item',array('customer_id' => $primary_key));
		$this->db->delete('message',array('customer_id' => $primary_key));
		$this->db->delete('confirmation',array('customer_id' => $primary_key));
		$this->db->delete('customer',array('id' => $primary_key));
		
		return TRUE;
	}	


	public function customer_id($value, $row)

	{

		if($row->id < 10)

		{

			$customer_id = "000".$row->id;

		}

		elseif($row->id < 100)

		{

			$customer_id = "00".$row->id;

		}

		elseif($row->id < 1000)

		{

			$customer_id = "0".$row->id;

		}

		else

		{

			$customer_id = $row->id;

		}

		return $customer_id;

	}



	

	function image_callback_after_upload($uploader_response,$field_info, $files_to_upload)

    {

        //Is only one file uploaded so it ok to use it with $uploader_response[0].

        $file_uploaded = $field_info->upload_path.'/'.$uploader_response[0]->name; 

        $thumbnail = $field_info->upload_path.'/thumb/'.$uploader_response[0]->name;

		// Char_replace
		$char = array(',',';','*','!','@','#','$','%','^','&','(',')','+','}','{','[','],','--','---');
		$replace = "-";
		$new_name = str_replace($char,$replace,$uploader_response[0]->name);

		// Thumbs

		$config_res['image_library'] = 'gd2';

		$config_res['source_image'] = 'media/images/original/'.$uploader_response[0]->name;

		$config_res['maintain_ratio'] = FALSE;

		$config_res['width'] = 60;

		$config_res['height'] = 60;

		$config_res['new_image'] = 'media/images/thumb/'.$new_name;



		$this->image_lib->initialize($config_res);

		$this->image_lib->resize();



		// medium

		$config_res['image_library'] = 'gd2';

		$config_res['source_image'] = 'media/images/original/'.$uploader_response[0]->name;

		$config_res['maintain_ratio'] = TRUE;

		$config_res['width'] = 320;

		$config_res['height'] = 320;

		$config_res['new_image'] = 'media/images/medium/'.$new_name;



		$this->image_lib->initialize($config_res);

		$this->image_lib->resize();

		

		// large

		$config_res['image_library'] = 'gd2';

		$config_res['source_image'] = 'media/images/original/'.$uploader_response[0]->name;

		$config_res['maintain_ratio'] = TRUE;

		$config_res['width'] = 640;

		$config_res['height'] = 640;

		$config_res['new_image'] = 'media/images/large/'.$new_name;



		$this->image_lib->initialize($config_res);

		$this->image_lib->resize();
		
		
		// original

		$config_res['image_library'] = 'gd2';

		$config_res['source_image'] = 'media/images/original/'.$uploader_response[0]->name;

		$config_res['maintain_ratio'] = TRUE;

		$config_res['width'] = 1024;

		$config_res['height'] = 1024;

		$config_res['new_image'] = 'media/images/original/'.$new_name;



		$this->image_lib->initialize($config_res);

		$this->image_lib->resize();

		
		
		
        return true;

    }
	
	//--- END OF CALLBACK --//
	
	// TAMBAHAN CALLBACK //
	public function callback_customer_status($value, $row)
	{
	  	if($row->status == "Moderate"){
			return "<a href='".base_url()."administrator/main/update_status_data_pelanggan/".$row->id."' class='btn btn-primary'>Active</a>";
		}
		else if($row->status == "Active")
		{
			return "<a href='".base_url()."administrator/main/update_status_data_pelanggan/".$row->id."' class='btn btn-warning'>Inactive</a>";
		}
		else
		{
			return "<a href='".base_url()."administrator/main/update_status_data_pelanggan/".$row->id."' class='btn btn-danger'>Moderate</a>";
		}
	
	}
	function image_callback_before_upload($files_to_upload,$field_info)

    {
         foreach($files_to_upload as $value);
			$name = $value['name'];
		 
		if (!preg_match("/^[\w |\.-]+$/",$name))
			{
			return "Periksa kembali file upload anda !!";
			}
			else
			{
				return true;
			}
	}

    // END TAMBAHAN CALLBACK //
}	